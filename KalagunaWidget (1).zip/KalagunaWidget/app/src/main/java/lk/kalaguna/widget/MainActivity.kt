package lk.kalaguna.widget

import android.app.Activity
import android.app.WallpaperManager
import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Intent
import android.os.Bundle
import android.util.TypedValue
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.MainScope
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.roundToInt

/** Settings screen: pick a city, switch language, refresh, and add the widget to the home screen. */
class MainActivity : Activity() {

    private val scope = MainScope()
    private lateinit var prefs: Prefs
    private var configWidgetId = AppWidgetManager.INVALID_APPWIDGET_ID

    private val sriLankaCities = listOf(
        Place("Chilaw", "North Western", 7.5758, 79.7953, "හලාවත"),
        Place("Madampe", "North Western", 7.4990, 79.8400, "මාදම්පේ"),
        Place("Panirendawa", "North Western", 7.4937, 79.9007, "පනිරෙන්ඩාව"),
        Place("Colombo", "Western", 6.9271, 79.8612, "කොළඹ"),
        Place("Kandy", "Central", 7.2906, 80.6337, "මහනුවර"),
        Place("Galle", "Southern", 6.0535, 80.2210, "ගාල්ල"),
        Place("Nuwara Eliya", "Central", 6.9497, 80.7891, "නුවරඑළිය"),
        Place("Jaffna", "Northern", 9.6615, 80.0255, "යාපනය"),
        Place("Kurunegala", "North Western", 7.4818, 80.3609, "කුරුණෑගල"),
        Place("Anuradhapura", "North Central", 8.3114, 80.4037, "අනුරාධපුරය"),
        Place("Trincomalee", "Eastern", 8.5874, 81.2152, "ත්‍රිකුණාමලය"),
        Place("Batticaloa", "Eastern", 7.7310, 81.6747, "මඩකලපුව"),
        Place("Matara", "Southern", 5.9549, 80.5550, "මාතර"),
        Place("Ratnapura", "Sabaragamuwa", 6.6828, 80.3992, "රත්නපුරය"),
        Place("Badulla", "Uva", 6.9934, 81.0550, "බදුල්ල"),
    )

    private val en get() = prefs.english
    private fun t(si: String, english: String) = if (en) english else si

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        prefs = Prefs(this)

        // Opened by the launcher while adding the widget: keep the widget even if the user just goes back.
        configWidgetId = intent?.extras?.getInt(
            AppWidgetManager.EXTRA_APPWIDGET_ID, AppWidgetManager.INVALID_APPWIDGET_ID
        ) ?: AppWidgetManager.INVALID_APPWIDGET_ID
        if (configWidgetId != AppWidgetManager.INVALID_APPWIDGET_ID) {
            setResult(RESULT_OK, Intent().putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, configWidgetId))
            WeatherWorker.schedule(this)
            WidgetRenderer.updateAll(this)
        }

        val input = findViewById<EditText>(R.id.search_input)
        findViewById<Button>(R.id.search_btn).setOnClickListener { search(input) }
        input.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_SEARCH) { search(input); true } else false
        }
        findViewById<Button>(R.id.pin_btn).setOnClickListener { pinWidget() }
        findViewById<Button>(R.id.refresh_btn).setOnClickListener { loadWeather() }
        findViewById<Button>(R.id.wallpaper_btn).setOnClickListener { setLiveWallpaper() }
        findViewById<TextView>(R.id.lang_btn).setOnClickListener {
            prefs.english = !prefs.english
            applyLanguage()
            WidgetRenderer.updateAll(this)
        }

        applyLanguage()
        if (prefs.snapshot == null) loadWeather()
    }

    override fun onDestroy() {
        scope.cancel()
        super.onDestroy()
    }

    private fun applyLanguage() {
        findViewById<TextView>(R.id.lang_btn).text = if (en) "සිංහල" else "English"
        findViewById<TextView>(R.id.title).text = t("කාලගුණ Widget", "Weather Widget")
        findViewById<TextView>(R.id.subtitle).text =
            t("ඔයාගේ නගරය තෝරලා widget එක home screen එකට දාන්න", "Pick your town and add the widget to your home screen")
        findViewById<TextView>(R.id.label_cities).text = t("ලංකාවේ නගර", "Sri Lankan towns")
        findViewById<TextView>(R.id.label_search).text = t("වෙනත් නගරයක් හොයන්න", "Search another place")
        findViewById<EditText>(R.id.search_input).hint = t("උදා: Ella, Dubai", "e.g. Ella, Dubai")
        findViewById<Button>(R.id.search_btn).text = t("හොයන්න", "Search")
        findViewById<Button>(R.id.pin_btn).text = t("➕  Widget එක Home Screen එකට දාන්න", "➕  Add widget to Home Screen")
        findViewById<Button>(R.id.refresh_btn).text = t("⟳  දැන් Refresh කරන්න", "⟳  Refresh now")
        findViewById<Button>(R.id.wallpaper_btn).text = t("🌧️  Live Wallpaper එක දාන්න", "🌧️  Set live wallpaper")
        findViewById<TextView>(R.id.help).text = t(
            "අතින් දාන්න නම්: Home screen එකේ හිස් තැනක් ඔබාගෙන ඉන්න → Widgets → \"කාලගුණය\" → widget එක ඇදලා දාන්න.\n\n" +
                "Widget එක ඔබන්න = මේ app එක open වෙනවා. ⟳ = අලුත් කාලගුණය. EN/සිං = භාෂාව මාරු කරන්න. " +
                "Live Wallpaper එකත් මේ නගරයේම කාලගුණය පෙන්නනවා. " +
                "සෑම විනාඩි 30කට වරක් auto update වෙනවා.",
            "To add it yourself: long-press an empty spot on the home screen → Widgets → \"කාලගුණය\" → drag the widget in.\n\n" +
                "Tap the widget = open this app. ⟳ = fresh weather. EN/සිං = switch language. " +
                "The live wallpaper shows the same town's weather. " +
                "Updates automatically every 30 minutes."
        )
        buildQuickCities()
        findViewById<LinearLayout>(R.id.results).removeAllViews()
        showCard()
    }

    private fun dp(v: Int) = TypedValue.applyDimension(
        TypedValue.COMPLEX_UNIT_DIP, v.toFloat(), resources.displayMetrics
    ).toInt()

    private fun buildQuickCities() {
        val row = findViewById<LinearLayout>(R.id.quick_cities)
        row.removeAllViews()
        sriLankaCities.forEach { place ->
            val chip = TextView(this).apply {
                text = place.label(en)
                setTextColor(getColor(R.color.text_main))
                textSize = 14f
                setPadding(dp(16), dp(9), dp(16), dp(9))
                background = getDrawable(R.drawable.chip_bg)
                setOnClickListener { choose(place) }
            }
            row.addView(chip, LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply { marginEnd = dp(8) })
        }
    }

    private fun search(input: EditText) {
        val q = input.text.toString()
        if (q.isBlank()) return
        (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager)
            .hideSoftInputFromWindow(input.windowToken, 0)
        val results = findViewById<LinearLayout>(R.id.results)
        results.removeAllViews()
        results.addView(resultRow(t("හොයමින්…", "Searching…"), null))
        scope.launch {
            val found = try {
                withContext(Dispatchers.IO) { WeatherApi.searchCity(q) }
            } catch (e: Exception) {
                null
            }
            results.removeAllViews()
            when {
                found == null -> results.addView(resultRow(t("Internet සම්බන්ධතාවය බලන්න", "Check your internet connection"), null))
                found.isEmpty() -> results.addView(resultRow(t("\"$q\" හමු වුණේ නැහැ", "\"$q\" not found"), null))
                else -> found.forEach { results.addView(resultRow("${it.name}  ·  ${it.region}", it)) }
            }
        }
    }

    private fun resultRow(label: String, place: Place?) = TextView(this).apply {
        text = label
        setTextColor(getColor(if (place != null) R.color.text_main else R.color.text_soft))
        textSize = 15f
        setPadding(dp(4), dp(12), dp(4), dp(12))
        if (place != null) setOnClickListener { choose(place) }
    }

    private fun choose(place: Place) {
        prefs.setPlace(place)
        findViewById<LinearLayout>(R.id.results).removeAllViews()
        WidgetRenderer.updateAll(this) // shows "loading" with the new city name
        Toast.makeText(this, t("${place.label(false)} තෝරා ගත්තා", "${place.name} selected"), Toast.LENGTH_SHORT).show()
        loadWeather()
        if (configWidgetId != AppWidgetManager.INVALID_APPWIDGET_ID) finish()
    }

    private fun loadWeather() {
        findViewById<TextView>(R.id.card_cond).text = Txt.loading(en)
        // The worker survives this screen closing; the direct fetch updates this screen quickly.
        WeatherWorker.refreshNow(this)
        scope.launch {
            try {
                val snap = withContext(Dispatchers.IO) { WeatherApi.fetch(prefs.lat, prefs.lon) }
                prefs.snapshot = snap
                WidgetRenderer.updateAll(this@MainActivity)
            } catch (e: Exception) {
                Toast.makeText(this@MainActivity, Txt.noData(en), Toast.LENGTH_SHORT).show()
            }
            showCard()
        }
    }

    private fun showCard() {
        val snap = prefs.snapshot
        findViewById<TextView>(R.id.card_city).text = "📍 ${prefs.cityLabel()}"
        findViewById<TextView>(R.id.card_temp).text = snap?.let { "${it.temp.roundToInt()}°C" } ?: "--°"
        findViewById<TextView>(R.id.card_cond).text = snap?.let { Txt.condition(it.code, en) } ?: Txt.noData(en)
        findViewById<ImageView>(R.id.card_icon).setImageResource(
            Scene.fromCode(snap?.code ?: 2).icon(snap?.isDay ?: true)
        )
    }

    /** Opens Android's live-wallpaper preview with our wallpaper selected (user taps "Set wallpaper"). */
    private fun setLiveWallpaper() {
        val direct = Intent(WallpaperManager.ACTION_CHANGE_LIVE_WALLPAPER).putExtra(
            WallpaperManager.EXTRA_LIVE_WALLPAPER_COMPONENT,
            ComponentName(this, WeatherWallpaperService::class.java)
        )
        try {
            startActivity(direct)
        } catch (e: Exception) {
            try {
                startActivity(Intent(WallpaperManager.ACTION_LIVE_WALLPAPER_CHOOSER))
                Toast.makeText(this, t("ලැයිස්තුවෙන් \"සජීවී කාලගුණ Wallpaper\" තෝරන්න", "Pick \"සජීවී කාලගුණ Wallpaper\" from the list"), Toast.LENGTH_LONG).show()
            } catch (e2: Exception) {
                Toast.makeText(this, t("මේ phone එකේ live wallpaper සපෝට් නැහැ", "This phone does not support live wallpapers"), Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun pinWidget() {
        val mgr = AppWidgetManager.getInstance(this)
        if (mgr.isRequestPinAppWidgetSupported) {
            mgr.requestPinAppWidget(ComponentName(this, WeatherWidgetProvider::class.java), null, null)
        } else {
            Toast.makeText(
                this,
                t("Home screen එකේ හිස් තැනක් ඔබාගෙන ඉන්න → Widgets → කාලගුණය", "Long-press the home screen → Widgets → කාලගුණය"),
                Toast.LENGTH_LONG
            ).show()
        }
    }
}
