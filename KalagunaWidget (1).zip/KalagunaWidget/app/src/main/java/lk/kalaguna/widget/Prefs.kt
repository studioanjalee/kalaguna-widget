package lk.kalaguna.widget

import android.content.Context

/** Saved city, language and the last downloaded weather. Default city is Colombo, default language Sinhala. */
class Prefs(context: Context) {
    private val sp = context.applicationContext.getSharedPreferences("kalaguna", Context.MODE_PRIVATE)

    val city: String get() = sp.getString("city", "Colombo") ?: "Colombo"
    val citySi: String get() = sp.getString("city_si", null) ?: if (city == "Colombo") "කොළඹ" else city
    val lat: Double get() = sp.getFloat("lat", 6.9271f).toDouble()
    val lon: Double get() = sp.getFloat("lon", 79.8612f).toDouble()

    /** true = English, false = Sinhala */
    var english: Boolean
        get() = sp.getBoolean("english", false)
        set(v) = sp.edit().putBoolean("english", v).apply()

    fun cityLabel(): String = if (english) city else citySi

    var snapshot: WeatherSnapshot?
        get() = WeatherSnapshot.fromJson(sp.getString("snapshot", null))
        set(v) = sp.edit().putString("snapshot", v?.toJson()).apply()

    fun listen(l: android.content.SharedPreferences.OnSharedPreferenceChangeListener) =
        sp.registerOnSharedPreferenceChangeListener(l)

    fun unlisten(l: android.content.SharedPreferences.OnSharedPreferenceChangeListener) =
        sp.unregisterOnSharedPreferenceChangeListener(l)

    fun setPlace(p: Place) {
        sp.edit()
            .putString("city", p.name)
            .putString("city_si", p.nameSi)
            .putFloat("lat", p.lat.toFloat())
            .putFloat("lon", p.lon.toFloat())
            .remove("snapshot") // old city's weather is no longer valid
            .apply()
    }
}
