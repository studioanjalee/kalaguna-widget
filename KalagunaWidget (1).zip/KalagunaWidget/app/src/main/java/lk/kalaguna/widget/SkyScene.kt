package lk.kalaguna.widget

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PorterDuff
import android.graphics.PorterDuffColorFilter
import android.graphics.PorterDuffXfermode
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.random.Random

/**
 * Draws the full-screen, realistic weather sky for the live wallpaper:
 * atmospheric sky gradients, volumetric clouds and overcast cloud decks that drift,
 * rain in three depths with wind, branching lightning that lights up the clouds,
 * snow, fog, sun, moon and stars. Everything moves with real time (dt in seconds).
 */
class SkyScene(context: Context) {

    private val res = context.resources
    private val dp = res.displayMetrics.density
    private val rnd = Random(System.nanoTime())

    private var w = 1080f
    private var h = 1920f
    private var t = 0f

    /** Home-screen page position 0..1 (gentle parallax when swiping pages). */
    var pageOffset = 0.5f

    private var scene = Scene.PARTLY
    private var isDay = true
    private var built = false

    // ---------------------------------------------------------------- bitmaps
    private val cache = HashMap<Int, Bitmap>()
    private fun bmp(id: Int): Bitmap = cache.getOrPut(id) { BitmapFactory.decodeResource(res, id) }

    private val softDot: Bitmap by lazy {
        val s = 48
        Bitmap.createBitmap(s, s, Bitmap.Config.ARGB_8888).also { b ->
            val p = Paint(Paint.ANTI_ALIAS_FLAG)
            p.shader = RadialGradient(
                s / 2f, s / 2f, s / 2f,
                intArrayOf(Color.WHITE, Color.argb(190, 255, 255, 255), Color.TRANSPARENT),
                floatArrayOf(0f, 0.35f, 1f), Shader.TileMode.CLAMP
            )
            Canvas(b).drawCircle(s / 2f, s / 2f, s / 2f, p)
        }
    }

    // ---------------------------------------------------------------- paints
    private val skyPaint = Paint()
    private val hazePaint = Paint()
    private val bmpPaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val glowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { xfermode = PorterDuffXfermode(PorterDuff.Mode.SCREEN) }
    private val boltPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }
    private val rect = RectF()

    // ---------------------------------------------------------------- moving things
    private class Sprite(
        var x: Float, val y: Float, val width: Float, val resId: Int,
        val speed: Float, val parallax: Float, val alpha: Int, val filter: PorterDuffColorFilter?,
    )

    /** A horizontally tiling cloud deck (overcast layer). */
    private class Deck(
        val resId: Int, val top: Float, val width: Float, val speed: Float,
        val parallax: Float, val alpha: Int, val filter: PorterDuffColorFilter?, var x: Float = 0f,
    )

    private val backDecks = ArrayList<Deck>()
    private val clouds = ArrayList<Sprite>()
    private val frontDecks = ArrayList<Deck>()
    private val fog = ArrayList<Sprite>()

    /** Big soft streaky cloud that drifts across the sky and sways back and forth. */
    private class Wisp(
        var x: Float, val y: Float, val width: Float, val resId: Int, val speed: Float,
        val sway: Float, val swayFreq: Float, val bob: Float, val phase: Float,
        val parallax: Float, val alpha: Int, val filter: PorterDuffColorFilter?,
    )

    private val wisps = ArrayList<Wisp>()
    private val wispIds = intArrayOf(
        R.drawable.wisp_1, R.drawable.wisp_2, R.drawable.wisp_3,
        R.drawable.wisp_4, R.drawable.wisp_5, R.drawable.wisp_6,
    )

    /** Rain in three depths. Each drop: x, y, scale, alpha. */
    private class RainLayer(val resId: Int, val count: Int, val speed: Float, val lenDp: Float, val alphaMax: Int) {
        var d = FloatArray(0)
    }

    private val rain = ArrayList<RainLayer>()
    private var windDeg = 0f

    // snow: x, y, radius, speed, phase
    private var flakes = FloatArray(0)
    private val FLAKE = 5

    // stars: x, y, size, phase, twinkle speed
    private var stars = FloatArray(0)
    private val STAR = 5

    // lightning
    private var lightning = false
    private var nextStrike = 3f
    private var strikeAge = -1f
    private var strikeHasBolt = false
    private val boltMain = Path()
    private val boltBranches = Path()
    private var glowX = 0f
    private var glowY = 0f
    private var glowShader: RadialGradient? = null

    // ---------------------------------------------------------------- setup
    fun resize(width: Int, height: Int) {
        if (width.toFloat() == w && height.toFloat() == h && built) return
        w = max(1, width).toFloat()
        h = max(1, height).toFloat()
        build()
    }

    /** Reads the saved weather. Rebuilds the sky only if the weather type or day/night changed. */
    fun reload(prefs: Prefs) {
        val snap = prefs.snapshot
        val newScene = Scene.fromCode(snap?.code ?: 2)
        val newDay = snap?.isDay ?: true
        if (!built || newScene != scene || newDay != isDay) {
            scene = newScene
            isDay = newDay
            build()
        }
    }

    private fun c(hex: String) = Color.parseColor(hex)

    /** Real skies: deep at the zenith, paler and hazier towards the horizon. */
    private fun skyColors(): IntArray {
        val night = arrayOf("#0D121D", "#161E2D", "#212B3D", "#2B3649")
        val hex = when (scene) {
            Scene.CLEAR, Scene.PARTLY ->
                if (isDay) arrayOf("#1B5FC4", "#3C8BE0", "#8EC3EF", "#D3E8F7") else arrayOf("#050A1F", "#0E1A40", "#1D2D5C", "#2E4274")
            Scene.CLOUDY -> if (isDay) arrayOf("#6F7F93", "#8C9AAB", "#A9B4C1", "#C2CAD3") else night
            Scene.RAIN -> if (isDay) arrayOf("#3A4350", "#4E5866", "#66707D", "#828B95") else night
            Scene.STORM -> arrayOf("#14171E", "#1F232C", "#2C313B", "#3A404A")
            Scene.SNOW -> if (isDay) arrayOf("#9AA6B4", "#B3BDC8", "#C9D1DA", "#DDE3E9") else night
            Scene.FOG -> if (isDay) arrayOf("#8E99A5", "#A5AEB8", "#BCC3CB", "#CFD5DB") else night
        }
        return IntArray(4) { c(hex[it]) }
    }

    private fun multiply(color: Int) = PorterDuffColorFilter(color, PorterDuff.Mode.MULTIPLY)

    private fun build() {
        built = true
        t = 0f
        skyPaint.shader = LinearGradient(0f, 0f, 0f, h, skyColors(), floatArrayOf(0f, 0.38f, 0.75f, 1f), Shader.TileMode.CLAMP)

        val wet = scene == Scene.RAIN || scene == Scene.STORM
        val misty = wet || scene == Scene.FOG || scene == Scene.SNOW
        // low haze near the horizon (rain mist, fog)
        hazePaint.shader = if (misty) LinearGradient(
            0f, h * 0.45f, 0f, h,
            intArrayOf(Color.TRANSPARENT, Color.argb(if (scene == Scene.FOG) 120 else 60, 205, 212, 222)),
            null, Shader.TileMode.CLAMP
        ) else null

        val nightTint = if (!isDay) multiply(c("#5E6A82")) else null

        // ---- overcast decks
        backDecks.clear(); frontDecks.clear()
        fun deck(list: ArrayList<Deck>, id: Int, topFrac: Float, widthFrac: Float, speedDp: Float, par: Float, a: Int, f: PorterDuffColorFilter?) {
            list += Deck(id, h * topFrac, w * widthFrac, speedDp * dp, par, a, f, rnd.nextFloat() * w)
        }
        when (scene) {
            Scene.CLOUDY, Scene.SNOW -> {
                deck(backDecks, R.drawable.deck_light, -0.10f, 2.4f, 5f, 0.03f, 255, nightTint)
                deck(frontDecks, R.drawable.deck_light, -0.06f, 1.9f, 11f, 0.08f, 200, nightTint ?: multiply(c("#E2E7EE")))
            }
            Scene.FOG -> deck(backDecks, R.drawable.deck_light, -0.10f, 2.4f, 4f, 0.03f, 170, nightTint)
            Scene.RAIN -> {
                deck(backDecks, R.drawable.deck_dark, -0.10f, 2.6f, 7f, 0.03f, 255, nightTint)
                deck(frontDecks, R.drawable.deck_dark, -0.07f, 2.1f, 14f, 0.07f, 215, nightTint)
                deck(frontDecks, R.drawable.deck_scud, 0.10f, 1.6f, 26f, 0.12f, 190, nightTint)
            }
            Scene.STORM -> {
                val dark = multiply(c(if (isDay) "#8C929C" else "#5A6170"))
                deck(backDecks, R.drawable.deck_dark, -0.10f, 2.8f, 9f, 0.03f, 255, dark)
                deck(frontDecks, R.drawable.deck_dark, -0.07f, 2.2f, 18f, 0.07f, 230, dark)
                deck(frontDecks, R.drawable.deck_scud, 0.12f, 1.7f, 34f, 0.12f, 200, multiply(c("#8A929E")))
            }
            else -> Unit
        }

        // ---- individual cumulus clouds (far -> near)
        clouds.clear()
        val count = when (scene) {
            Scene.CLEAR, Scene.PARTLY -> 0     // these skies use the soft streaky wisps below
            Scene.CLOUDY -> 3
            Scene.RAIN, Scene.STORM -> 0
            Scene.SNOW, Scene.FOG -> 2
        }
        val ids = intArrayOf(R.drawable.cloud_a, R.drawable.cloud_b, R.drawable.cloud_c, R.drawable.cloud_d)
        for (i in 0 until count) {
            val depth = if (count == 1) 1f else i / (count - 1f)        // 0 = far, 1 = near
            val small = scene == Scene.CLEAR
            val width = ((if (small) 90f else 120f) + (if (small) 70f else 230f) * depth) * dp * (0.85f + rnd.nextFloat() * 0.3f)
            val top = h * (0.04f + 0.10f * depth + rnd.nextFloat() * (0.12f + 0.22f * depth))
            // far clouds fade into the sky (atmospheric perspective)
            val filter = when {
                !isDay -> multiply(c("#59657C"))
                scene == Scene.CLOUDY || scene == Scene.SNOW || scene == Scene.FOG -> multiply(c("#C9D0DA"))
                depth < 0.5f -> multiply(c("#E4ECF7"))
                else -> null
            }
            clouds += Sprite(
                x = rnd.nextFloat() * (w + width) - width, y = top, width = width, resId = ids[rnd.nextInt(ids.size)],
                speed = (3f + 14f * depth) * dp, parallax = 0.03f + 0.12f * depth,
                alpha = (170 + 85 * depth).toInt(), filter = filter,
            )
        }
        buildWisps()

        // ---- fog bands
        fog.clear()
        if (scene == Scene.FOG) repeat(7) { i ->
            val width = w * (1.2f + rnd.nextFloat() * 0.6f)
            fog += Sprite(rnd.nextFloat() * w - width / 2, h * (0.22f + 0.1f * i), width, R.drawable.fog_band,
                (7f + 6f * rnd.nextFloat()) * dp * (if (i % 2 == 0) 1f else -1f), 0.08f,
                if (isDay) 150 else 60, if (isDay) null else multiply(c("#8A96AA")))
        }

        // ---- rain: far / mid / near
        rain.clear()
        if (wet) {
            val storm = scene == Scene.STORM
            windDeg = if (storm) 15f else 7f
            rain += RainLayer(R.drawable.streak_far, if (storm) 260 else 190, 720f * dp, 26f, 150)
            rain += RainLayer(R.drawable.streak_mid, if (storm) 110 else 75, 1050f * dp, 48f, 190)
            rain += RainLayer(R.drawable.streak_near, if (storm) 22 else 14, 1500f * dp, 90f, 170)
            val spanW = w * 1.7f
            for (L in rain) {
                L.d = FloatArray(L.count * 4)
                for (i in 0 until L.count) {
                    val o = i * 4
                    L.d[o] = rnd.nextFloat() * spanW - w * 0.35f
                    L.d[o + 1] = rnd.nextFloat() * h * 1.2f - h * 0.1f
                    L.d[o + 2] = 0.75f + rnd.nextFloat() * 0.5f
                    L.d[o + 3] = L.alphaMax * (0.45f + 0.55f * rnd.nextFloat())
                }
            }
        }

        // ---- snow
        val nFlakes = if (scene == Scene.SNOW) 160 else 0
        flakes = FloatArray(nFlakes * FLAKE)
        for (i in 0 until nFlakes) {
            val near = rnd.nextFloat()
            val o = i * FLAKE
            flakes[o] = rnd.nextFloat() * w
            flakes[o + 1] = rnd.nextFloat() * h
            flakes[o + 2] = (1.6f + 5.5f * near * near) * dp
            flakes[o + 3] = (28f + 75f * near) * dp
            flakes[o + 4] = rnd.nextFloat() * 6.28f
        }

        // ---- stars (only when the sky is clear-ish at night)
        val nStars = if (!isDay && (scene == Scene.CLEAR || scene == Scene.PARTLY)) 110 else 0
        stars = FloatArray(nStars * STAR)
        for (i in 0 until nStars) {
            val o = i * STAR
            stars[o] = rnd.nextFloat() * w
            stars[o + 1] = rnd.nextFloat() * rnd.nextFloat() * h * 0.8f
            stars[o + 2] = (3f + rnd.nextFloat() * rnd.nextFloat() * 12f) * dp
            stars[o + 3] = rnd.nextFloat() * 6.28f
            stars[o + 4] = 0.8f + rnd.nextFloat() * 2.2f
        }

        lightning = scene == Scene.STORM
        nextStrike = 1.5f + rnd.nextFloat() * 3f
        strikeAge = -1f
    }

    private fun buildWisps() {
        wisps.clear()
        if (scene != Scene.CLEAR && scene != Scene.PARTLY) return
        val count = when {
            scene == Scene.PARTLY && isDay -> 15
            scene == Scene.CLEAR && isDay -> 10
            scene == Scene.PARTLY -> 9
            else -> 4
        }
        val nightFilter = if (isDay) null else multiply(c("#6C7A95"))
        val list = ArrayList<Wisp>()
        // two thin, very wide haze sheets low in the sky (like the milky band near the horizon)
        repeat(if (isDay) 2 else 1) {
            val width = w * (1.3f + rnd.nextFloat() * 0.5f)
            list += Wisp(
                x = rnd.nextFloat() * w - width / 2, y = h * (0.30f + rnd.nextFloat() * 0.18f), width = width,
                resId = R.drawable.wisp_sheet, speed = (8f + rnd.nextFloat() * 6f) * dp,
                sway = (30f + rnd.nextFloat() * 30f) * dp, swayFreq = 0.02f + rnd.nextFloat() * 0.02f,
                bob = 3f * dp, phase = rnd.nextFloat() * 6.28f, parallax = 0.04f,
                alpha = if (isDay) 150 else 80, filter = nightFilter,
            )
        }
        for (i in 0 until count) {
            val depth = rnd.nextFloat()                                   // 0 = high & far, 1 = low & near
            val width = (260f + 320f * depth) * dp * (0.85f + rnd.nextFloat() * 0.3f)
            // high clouds drift one way, lower clouds the other way -> lively "එහා මෙහා" motion
            val dir = if (depth < 0.35f) -1f else 1f
            list += Wisp(
                x = rnd.nextFloat() * (w + width) - width,
                y = h * (0.0f + 0.55f * (0.25f * depth + 0.75f * rnd.nextFloat())) - width * 0.12f,
                width = width,
                resId = wispIds[rnd.nextInt(wispIds.size)],
                speed = dir * (12f + 34f * depth) * dp,
                sway = (25f + 60f * rnd.nextFloat()) * dp,
                swayFreq = 0.03f + rnd.nextFloat() * 0.05f,
                bob = (2f + 6f * rnd.nextFloat()) * dp,
                phase = rnd.nextFloat() * 6.28f,
                parallax = 0.03f + 0.12f * depth,
                alpha = if (isDay) (140 + 115 * depth).toInt() else (70 + 80 * depth).toInt(),
                filter = nightFilter ?: if (depth < 0.4f) multiply(c("#EEF3FA")) else null,
            )
        }
        // two extra-large clouds that glide across in opposite directions, in front of the others
        if (isDay || scene == Scene.PARTLY) {
            val big = arrayOf(
                floatArrayOf(0.10f, 1f, 22f),    // y (fraction of screen), direction, speed dp/s
                floatArrayOf(0.30f, -1f, 18f),
            )
            val bigIds = intArrayOf(R.drawable.wisp_5, R.drawable.wisp_3)
            for ((k, b) in big.withIndex()) {
                val width = (720f + rnd.nextFloat() * 120f) * dp
                list += Wisp(
                    x = if (k == 0) -width * 0.2f else w - width * 0.8f,     // both already on screen at start
                    y = h * b[0],
                    width = width,
                    resId = bigIds[k],
                    speed = b[1] * b[2] * dp,
                    sway = (70f + rnd.nextFloat() * 30f) * dp,
                    swayFreq = 0.025f + rnd.nextFloat() * 0.015f,
                    bob = 6f * dp,
                    phase = rnd.nextFloat() * 6.28f,
                    parallax = 0.16f + 0.02f * k,
                    alpha = if (isDay) 240 else 140,
                    filter = nightFilter,
                )
            }
        }
        list.sortBy { it.parallax }   // far first, near last
        wisps += list
    }

    private fun drawWisps(cv: Canvas, dt: Float) {
        for (wp in wisps) {
            wp.x += wp.speed * dt
            val b = bmp(wp.resId)
            val height = wp.width * b.height / b.width
            val swayX = wp.sway * sin(t * wp.swayFreq * 6.2832f + wp.phase)
            // wrap around once it has fully left the screen (including the sway range)
            if (wp.speed > 0 && wp.x - wp.sway > w) wp.x = -wp.width - wp.sway - rnd.nextFloat() * w * 0.3f
            if (wp.speed < 0 && wp.x + wp.width + wp.sway < 0) wp.x = w + wp.sway + rnd.nextFloat() * w * 0.3f
            val px = wp.x + swayX - (pageOffset - 0.5f) * w * wp.parallax
            if (px > w || px + wp.width < 0) continue
            val py = wp.y + wp.bob * sin(t * 0.21f + wp.phase * 1.7f)
            rect.set(px, py, px + wp.width, py + height)
            bmpPaint.alpha = wp.alpha
            bmpPaint.colorFilter = wp.filter
            cv.drawBitmap(b, null, rect, bmpPaint)
        }
        bmpPaint.colorFilter = null
    }

    // ---------------------------------------------------------------- drawing
    fun draw(cv: Canvas, dt: Float) {
        t += dt
        cv.drawRect(0f, 0f, w, h, skyPaint)
        drawStars(cv)
        drawSunOrMoon(cv)
        drawDecks(cv, backDecks, dt)
        drawLightningGlow(cv, dt)           // light inside / behind the clouds
        drawWisps(cv, dt)
        drawSprites(cv, clouds, dt)
        drawDecks(cv, frontDecks, dt)
        drawBolt(cv)
        drawSprites(cv, fog, dt)
        if (hazePaint.shader != null) cv.drawRect(0f, h * 0.45f, w, h, hazePaint)
        drawRain(cv, dt)
        drawSnow(cv, dt)
        drawFlash(cv)
    }

    private fun drawBitmapCentered(cv: Canvas, id: Int, cx: Float, cy: Float, width: Float, alpha: Int = 255) {
        val b = bmp(id)
        val height = width * b.height / b.width
        rect.set(cx - width / 2, cy - height / 2, cx + width / 2, cy + height / 2)
        bmpPaint.alpha = alpha
        bmpPaint.colorFilter = null
        cv.drawBitmap(b, null, rect, bmpPaint)
    }

    private fun drawStars(cv: Canvas) {
        if (stars.isEmpty()) return
        val shift = (pageOffset - 0.5f) * w * 0.03f
        var o = 0
        while (o < stars.size) {
            val tw = 0.5f + 0.5f * sin(t * stars[o + 4] + stars[o + 3])
            drawBitmapCentered(cv, R.drawable.star, stars[o] - shift, stars[o + 1],
                stars[o + 2] * (0.75f + 0.35f * tw), (50 + 205 * tw).toInt())
            o += STAR
        }
    }

    private fun drawSunOrMoon(cv: Canvas) {
        if (scene != Scene.CLEAR && scene != Scene.PARTLY) return
        val shift = (pageOffset - 0.5f) * w * 0.06f
        val cx = w * 0.74f - shift
        val cy = h * 0.12f
        if (isDay) {
            val glow = w * 1.05f
            drawBitmapCentered(cv, R.drawable.sun_glow, cx, cy, glow)
            cv.save(); cv.rotate(t * 4f, cx, cy)
            drawBitmapCentered(cv, R.drawable.sun_rays, cx, cy, glow, 200)
            cv.restore()
            cv.save(); cv.rotate(-t * 2.5f, cx, cy)
            drawBitmapCentered(cv, R.drawable.sun_rays2, cx, cy, glow * 0.95f, 170)
            cv.restore()
            drawBitmapCentered(cv, R.drawable.sun_core, cx, cy, w * 0.30f * (1f + 0.012f * sin(t * 1.3f)))
        } else {
            drawBitmapCentered(cv, R.drawable.moon_glow, cx, cy, w * 0.8f)
            drawBitmapCentered(cv, R.drawable.moon, cx, cy, w * 0.30f)
        }
    }

    private fun drawDecks(cv: Canvas, list: List<Deck>, dt: Float) {
        for (d in list) {
            val b = bmp(d.resId)
            val dh = d.width * b.height / b.width
            d.x = (d.x + d.speed * dt) % d.width
            var x = d.x - d.width - (pageOffset - 0.5f) * w * d.parallax
            bmpPaint.alpha = d.alpha
            bmpPaint.colorFilter = d.filter
            while (x < w) {
                rect.set(x, d.top, x + d.width + 1f, d.top + dh)  // +1px hides the seam
                cv.drawBitmap(b, null, rect, bmpPaint)
                x += d.width
            }
        }
        bmpPaint.colorFilter = null
    }

    private fun drawSprites(cv: Canvas, list: List<Sprite>, dt: Float) {
        for (s in list) {
            s.x += s.speed * dt
            if (s.speed > 0 && s.x > w + s.width * 0.2f) s.x = -s.width * (1.05f + rnd.nextFloat() * 0.6f)
            if (s.speed < 0 && s.x < -s.width * 1.2f) s.x = w + rnd.nextFloat() * s.width * 0.3f
            val b = bmp(s.resId)
            val height = s.width * b.height / b.width
            val px = s.x - (pageOffset - 0.5f) * w * s.parallax
            if (px > w || px + s.width < 0) continue
            rect.set(px, s.y, px + s.width, s.y + height)
            bmpPaint.alpha = s.alpha
            bmpPaint.colorFilter = s.filter
            cv.drawBitmap(b, null, rect, bmpPaint)
        }
        bmpPaint.colorFilter = null
    }

    private fun drawRain(cv: Canvas, dt: Float) {
        if (rain.isEmpty()) return
        cv.save()
        cv.rotate(windDeg, w / 2, h / 2)   // wind: the whole rain field leans
        val spanW = w * 1.7f
        for (L in rain) {
            val b = bmp(L.resId)
            val baseLen = L.lenDp * dp
            val aspect = b.width.toFloat() / b.height
            var o = 0
            while (o < L.d.size) {
                val len = baseLen * L.d[o + 2]
                L.d[o + 1] += L.speed * L.d[o + 2] * dt
                if (L.d[o + 1] > h * 1.15f) {
                    L.d[o + 1] = -len - rnd.nextFloat() * h * 0.2f
                    L.d[o] = rnd.nextFloat() * spanW - w * 0.35f
                }
                val wd = len * aspect
                rect.set(L.d[o] - wd / 2, L.d[o + 1] - len, L.d[o] + wd / 2, L.d[o + 1])
                bmpPaint.alpha = L.d[o + 3].toInt()
                cv.drawBitmap(b, null, rect, bmpPaint)
                o += 4
            }
        }
        cv.restore()
    }

    private fun drawSnow(cv: Canvas, dt: Float) {
        if (flakes.isEmpty()) return
        var o = 0
        while (o < flakes.size) {
            val r = flakes[o + 2]
            flakes[o + 1] += flakes[o + 3] * dt
            flakes[o] += sin(t * 0.9f + flakes[o + 4]) * 14f * dp * dt - 6f * dp * dt
            if (flakes[o + 1] - r > h) { flakes[o + 1] = -r * 2; flakes[o] = rnd.nextFloat() * w }
            if (flakes[o] < -r * 2) flakes[o] += w + r * 4
            rect.set(flakes[o] - r * 2, flakes[o + 1] - r * 2, flakes[o] + r * 2, flakes[o + 1] + r * 2)
            bmpPaint.alpha = 230
            cv.drawBitmap(softDot, null, rect, bmpPaint)
            o += FLAKE
        }
    }

    // ---------------------------------------------------------------- lightning
    /** Brightness of the current strike at its age: a few rapid return strokes, like the real thing. */
    private fun strikeLevel(age: Float): Float = when {
        age < 0f -> 0f
        age < 0.06f -> 1f
        age < 0.10f -> 0.15f
        age < 0.16f -> 0.85f
        age < 0.23f -> 0.2f
        age < 0.29f -> 0.95f
        age < 0.45f -> 0.6f * (1f - (age - 0.29f) / 0.16f)
        else -> 0f
    }

    private fun startStrike() {
        strikeAge = 0f
        strikeHasBolt = rnd.nextFloat() < 0.7f       // otherwise: lightning hidden inside the clouds
        glowX = w * (0.15f + rnd.nextFloat() * 0.7f)
        glowY = h * (0.10f + rnd.nextFloat() * 0.12f)
        glowShader = RadialGradient(
            glowX, glowY, w * (0.55f + rnd.nextFloat() * 0.3f),
            intArrayOf(Color.argb(255, 225, 228, 255), Color.argb(90, 200, 205, 245), Color.TRANSPARENT),
            floatArrayOf(0f, 0.45f, 1f), Shader.TileMode.CLAMP
        )
        boltMain.reset(); boltBranches.reset()
        if (strikeHasBolt) {
            val endY = h * (0.55f + rnd.nextFloat() * 0.4f)
            buildBolt(boltMain, glowX, glowY + h * 0.06f, endY, 0)
        }
    }

    /** Jagged lightning channel heading down, with forks that fade off sideways. */
    private fun buildBolt(path: Path, x0: Float, y0: Float, yEnd: Float, depth: Int) {
        var x = x0
        var y = y0
        var heading = (Math.PI / 2).toFloat() + (rnd.nextFloat() - 0.5f) * 0.4f
        path.moveTo(x, y)
        val step = 9f * dp
        val maxSteps = ((yEnd - y0) / step * 1.3f).toInt().coerceAtLeast(4)
        for (i in 0 until maxSteps) {
            heading += (rnd.nextFloat() - 0.5f) * 1.1f
            heading = 0.7f * heading + 0.3f * (Math.PI / 2).toFloat()
            val s = step * (0.5f + rnd.nextFloat())
            x += cos(heading) * s
            y += sin(heading) * s
            path.lineTo(x, y)
            if (depth < 2 && rnd.nextFloat() < (if (depth == 0) 0.10f else 0.05f)) {
                val forkLen = (yEnd - y) * (0.2f + rnd.nextFloat() * 0.35f)
                val sub = Path()
                buildBranch(sub, x, y, heading + (if (rnd.nextBoolean()) 1 else -1) * (0.5f + rnd.nextFloat() * 0.6f), forkLen)
                boltBranches.addPath(sub)
            }
            if (y >= yEnd) break
        }
    }

    private fun buildBranch(path: Path, x0: Float, y0: Float, startHeading: Float, length: Float) {
        var x = x0
        var y = y0
        var heading = startHeading
        path.moveTo(x, y)
        var travelled = 0f
        while (travelled < length) {
            heading += (rnd.nextFloat() - 0.5f) * 1.0f
            heading = 0.8f * heading + 0.2f * (Math.PI / 2).toFloat()
            val s = 7f * dp * (0.5f + rnd.nextFloat())
            x += cos(heading) * s
            y += sin(heading) * s
            travelled += s
            path.lineTo(x, y)
        }
    }

    private fun drawLightningGlow(cv: Canvas, dt: Float) {
        if (!lightning) return
        nextStrike -= dt
        if (strikeAge < 0f && nextStrike <= 0f) {
            startStrike()
            nextStrike = 2.5f + rnd.nextFloat() * 7f
        }
        if (strikeAge >= 0f) {
            strikeAge += dt
            if (strikeAge > 0.5f) strikeAge = -1f
        }
        val lv = strikeLevel(strikeAge)
        if (lv <= 0f || glowShader == null) return
        glowPaint.shader = glowShader
        glowPaint.alpha = (lv * 230).toInt()
        cv.drawRect(0f, 0f, w, h * 0.75f, glowPaint)
    }

    private fun drawBolt(cv: Canvas) {
        if (!lightning || !strikeHasBolt) return
        val lv = strikeLevel(strikeAge)
        if (lv < 0.3f) return
        // glow passes from wide & faint to thin & bright
        val passes = arrayOf(
            floatArrayOf(22f, 0.05f), floatArrayOf(12f, 0.10f), floatArrayOf(6f, 0.22f),
            floatArrayOf(3f, 0.55f), floatArrayOf(1.4f, 1f),
        )
        for ((i, p) in passes.withIndex()) {
            boltPaint.color = if (i == passes.size - 1) Color.WHITE else Color.rgb(205, 200, 255)
            boltPaint.alpha = (p[1] * lv * 255).toInt().coerceIn(0, 255)
            boltPaint.strokeWidth = p[0] * dp
            cv.drawPath(boltMain, boltPaint)
            boltPaint.strokeWidth = p[0] * dp * 0.55f
            boltPaint.alpha = (p[1] * lv * 200).toInt().coerceIn(0, 255)
            cv.drawPath(boltBranches, boltPaint)
        }
    }

    private fun drawFlash(cv: Canvas) {
        if (!lightning) return
        val lv = strikeLevel(strikeAge)
        if (lv <= 0f) return
        cv.drawColor(Color.argb(min(255, (lv * (if (strikeHasBolt) 70 else 40)).toInt()), 225, 228, 255))
    }
}
