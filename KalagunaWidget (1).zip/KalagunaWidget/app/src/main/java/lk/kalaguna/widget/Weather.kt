package lk.kalaguna.widget

import org.json.JSONArray
import org.json.JSONObject

/** One small forecast slot shown in the bottom row of the widget. [hour] is 0..23 local time. */
data class HourSlot(val hour: Int, val temp: Double, val code: Int, val isDay: Boolean)

/** Everything the widget needs to draw itself. Stored as JSON so it works offline. */
data class WeatherSnapshot(
    val temp: Double,
    val feelsLike: Double,
    val humidity: Int,
    val windKmh: Double,
    val code: Int,
    val isDay: Boolean,
    val max: Double,
    val min: Double,
    val hours: List<HourSlot>,
    val updatedAt: Long,
) {
    fun toJson(): String = JSONObject().apply {
        put("v", 2)
        put("temp", temp); put("feels", feelsLike)
        put("hum", humidity); put("wind", windKmh); put("code", code)
        put("day", isDay); put("max", max); put("min", min); put("at", updatedAt)
        put("hours", JSONArray().apply {
            hours.forEach {
                put(JSONObject().put("h", it.hour).put("temp", it.temp)
                    .put("code", it.code).put("day", it.isDay))
            }
        })
    }.toString()

    companion object {
        fun fromJson(s: String?): WeatherSnapshot? {
            if (s == null) return null
            return try {
                val o = JSONObject(s)
                if (o.optInt("v") != 2) return null // old format -> download again
                val arr = o.getJSONArray("hours")
                WeatherSnapshot(
                    temp = o.getDouble("temp"),
                    feelsLike = o.getDouble("feels"),
                    humidity = o.getInt("hum"),
                    windKmh = o.getDouble("wind"),
                    code = o.getInt("code"),
                    isDay = o.getBoolean("day"),
                    max = o.getDouble("max"),
                    min = o.getDouble("min"),
                    hours = (0 until arr.length()).map { i ->
                        val h = arr.getJSONObject(i)
                        HourSlot(h.getInt("h"), h.getDouble("temp"), h.getInt("code"), h.getBoolean("day"))
                    },
                    updatedAt = o.getLong("at"),
                )
            } catch (e: Exception) {
                null
            }
        }
    }
}

/** Weather type, chosen from the WMO weather code. */
enum class Scene {
    CLEAR, PARTLY, CLOUDY, FOG, RAIN, SNOW, STORM;

    /** Which animated layers are switched on, by day and by night. */
    fun layers(isDay: Boolean): Set<Int> = if (isDay) dayLayers() else nightLayers()

    private fun dayLayers(): Set<Int> = when (this) {
        CLEAR -> setOf(R.id.l_sun, R.id.l_wisp, R.id.l_white_far)
        PARTLY -> setOf(R.id.l_sun, R.id.l_white_far, R.id.l_white_back, R.id.l_white_front)
        CLOUDY -> setOf(R.id.l_grey_far, R.id.l_grey_back, R.id.l_grey_front)
        FOG -> setOf(R.id.l_grey_far, R.id.l_fog_back, R.id.l_fog_front)
        RAIN -> setOf(R.id.l_dark_far, R.id.l_dark_back, R.id.l_rain_back, R.id.l_rain_front, R.id.l_dark_front)
        SNOW -> setOf(R.id.l_grey_far, R.id.l_white_back, R.id.l_snow_back, R.id.l_snow_front, R.id.l_white_front)
        STORM -> setOf(R.id.l_dark_far, R.id.l_dark_back, R.id.l_rain_back, R.id.l_lightning, R.id.l_rain_front, R.id.l_dark_front)
    }

    private fun nightLayers(): Set<Int> = when (this) {
        CLEAR -> setOf(R.id.l_stars, R.id.l_moon)
        PARTLY -> setOf(R.id.l_stars, R.id.l_moon, R.id.l_night_far, R.id.l_night_back, R.id.l_night_front)
        CLOUDY -> setOf(R.id.l_night_far, R.id.l_night_back, R.id.l_night_front)
        FOG -> setOf(R.id.l_night_far, R.id.l_fog_night)
        RAIN -> setOf(R.id.l_night_far, R.id.l_night_back, R.id.l_rain_back, R.id.l_rain_front, R.id.l_night_front)
        SNOW -> setOf(R.id.l_night_far, R.id.l_night_back, R.id.l_snow_back, R.id.l_snow_front, R.id.l_night_front)
        STORM -> setOf(R.id.l_dark_far, R.id.l_dark_back, R.id.l_rain_back, R.id.l_lightning, R.id.l_rain_front, R.id.l_dark_front)
    }

    fun background(isDay: Boolean): Int = when (this) {
        CLEAR, PARTLY -> if (isDay) R.drawable.bg_clear_day else R.drawable.bg_clear_night
        CLOUDY -> if (isDay) R.drawable.bg_cloudy_day else R.drawable.bg_cloudy_night
        FOG -> if (isDay) R.drawable.bg_fog else R.drawable.bg_cloudy_night
        RAIN -> if (isDay) R.drawable.bg_rain else R.drawable.bg_cloudy_night
        SNOW -> if (isDay) R.drawable.bg_snow else R.drawable.bg_cloudy_night
        STORM -> R.drawable.bg_storm
    }

    fun icon(isDay: Boolean): Int = when (this) {
        CLEAR -> if (isDay) R.drawable.ic_w_clear_day else R.drawable.ic_w_clear_night
        PARTLY -> if (isDay) R.drawable.ic_w_partly_day else R.drawable.ic_w_partly_night
        CLOUDY -> R.drawable.ic_w_cloudy
        FOG -> R.drawable.ic_w_fog
        RAIN -> R.drawable.ic_w_rain
        SNOW -> R.drawable.ic_w_snow
        STORM -> R.drawable.ic_w_storm
    }

    companion object {
        /** Every layer view in the widget layouts, so the renderer can hide the unused ones. */
        val ALL_LAYERS = intArrayOf(
            R.id.l_stars, R.id.l_sun, R.id.l_moon, R.id.l_wisp,
            R.id.l_white_far, R.id.l_grey_far, R.id.l_dark_far, R.id.l_night_far,
            R.id.l_fog_back, R.id.l_fog_night,
            R.id.l_white_back, R.id.l_grey_back, R.id.l_dark_back, R.id.l_night_back,
            R.id.l_rain_back, R.id.l_snow_back,
            R.id.l_white_front, R.id.l_grey_front, R.id.l_dark_front, R.id.l_night_front,
            R.id.l_fog_front, R.id.l_rain_front, R.id.l_snow_front, R.id.l_lightning,
        )

        fun fromCode(code: Int): Scene = when (code) {
            0, 1 -> CLEAR
            2 -> PARTLY
            3 -> CLOUDY
            45, 48 -> FOG
            in 51..67, in 80..82 -> RAIN
            in 71..77, 85, 86 -> SNOW
            in 95..99 -> STORM
            else -> CLOUDY
        }
    }
}

/** All widget/app text in both languages. */
object Txt {
    fun condition(code: Int, en: Boolean): String = if (en) when (code) {
        0 -> "Clear sky"
        1 -> "Mostly clear"
        2 -> "Partly cloudy"
        3 -> "Cloudy"
        45, 48 -> "Fog"
        51, 53, 55 -> "Drizzle"
        56, 57 -> "Freezing drizzle"
        61 -> "Light rain"
        63 -> "Rain"
        65 -> "Heavy rain"
        66, 67 -> "Freezing rain"
        71, 73, 75, 77 -> "Snow"
        80 -> "Rain showers"
        81 -> "Showers"
        82 -> "Heavy showers"
        85, 86 -> "Snow showers"
        95 -> "Thunderstorm"
        96, 99 -> "Thunderstorm & hail"
        else -> "Weather"
    } else when (code) {
        0 -> "පැහැදිලි අහස"
        1 -> "බොහෝ දුරට පැහැදිලියි"
        2 -> "අර්ධ වශයෙන් වලාකුළු"
        3 -> "වලාකුළු සහිතයි"
        45, 48 -> "මීදුම"
        51, 53, 55 -> "පොද වැසි"
        56, 57 -> "සීතල පොද වැසි"
        61 -> "සුළු වැසි"
        63 -> "වැසි"
        65 -> "තද වැසි"
        66, 67 -> "සීතල වැසි"
        71, 73, 75, 77 -> "හිම පතනය"
        80 -> "වරින් වර වැසි"
        81 -> "වැසි ඇති වේ"
        82 -> "තද වැසි ඇති වේ"
        85, 86 -> "හිම වැසි"
        95 -> "ගිගුරුම් සහිත වැසි"
        96, 99 -> "ගිගුරුම් සහ අයිස් කැට"
        else -> "කාලගුණය"
    }

    /** 15 -> "3 PM" / "ප.ව. 3" */
    fun hour(h: Int, en: Boolean): String {
        val h12 = if (h % 12 == 0) 12 else h % 12
        return if (en) "$h12 ${if (h < 12) "AM" else "PM"}" else (if (h < 12) "පෙ.ව. " else "ප.ව. ") + h12
    }

    fun details(s: WeatherSnapshot, en: Boolean): String {
        val hi = Math.round(s.max); val lo = Math.round(s.min); val fl = Math.round(s.feelsLike)
        return if (en) "↑$hi° ↓$lo° · Feels $fl° · 💧${s.humidity}%"
        else "↑$hi° ↓$lo° · දැනෙන්නේ $fl° · 💧${s.humidity}%"
    }

    fun loading(en: Boolean) = if (en) "Getting weather…" else "කාලගුණය ලබාගනිමින්…"
    fun noData(en: Boolean) = if (en) "Connect to the internet and refresh" else "Internet සම්බන්ධ කර refresh කරන්න"

    /** Label on the language button = the language you switch TO. */
    fun langButton(en: Boolean) = if (en) "සිං" else "EN"
}
