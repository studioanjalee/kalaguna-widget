package lk.kalaguna.widget

import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.time.LocalDateTime

/** A place found by the city search. */
data class Place(
    val name: String,
    val region: String,
    val lat: Double,
    val lon: Double,
    val nameSi: String = name,
) {
    fun label(en: Boolean) = if (en) name else nameSi
}

/**
 * Talks to Open-Meteo (https://open-meteo.com): free, and no API key is needed.
 * Call these from a background thread.
 */
object WeatherApi {

    private fun get(url: String): String {
        val conn = URL(url).openConnection() as HttpURLConnection
        conn.connectTimeout = 15_000
        conn.readTimeout = 15_000
        conn.setRequestProperty("User-Agent", "KalagunaWidget/1.0")
        try {
            if (conn.responseCode !in 200..299) error("HTTP ${conn.responseCode}")
            return conn.inputStream.bufferedReader().use { it.readText() }
        } finally {
            conn.disconnect()
        }
    }

    fun fetch(lat: Double, lon: Double): WeatherSnapshot {
        val url = "https://api.open-meteo.com/v1/forecast?latitude=$lat&longitude=$lon" +
            "&current=temperature_2m,relative_humidity_2m,apparent_temperature,is_day,weather_code,wind_speed_10m" +
            "&hourly=temperature_2m,weather_code,is_day" +
            "&daily=temperature_2m_max,temperature_2m_min" +
            "&timezone=auto&forecast_days=2"
        val root = JSONObject(get(url))
        val cur = root.getJSONObject("current")
        val hourly = root.getJSONObject("hourly")
        val daily = root.getJSONObject("daily")

        // Next 4 slots, 3 hours apart, starting from the next full hour.
        val now = LocalDateTime.parse(cur.getString("time"))
        val times = hourly.getJSONArray("time")
        var start = 0
        while (start < times.length() && !LocalDateTime.parse(times.getString(start)).isAfter(now)) start++
        val hours = (0 until 4).mapNotNull { k ->
            val i = start + k * 3
            if (i >= times.length()) null else HourSlot(
                hour = LocalDateTime.parse(times.getString(i)).hour,
                temp = hourly.getJSONArray("temperature_2m").getDouble(i),
                code = hourly.getJSONArray("weather_code").getInt(i),
                isDay = hourly.getJSONArray("is_day").getInt(i) == 1,
            )
        }

        return WeatherSnapshot(
            temp = cur.getDouble("temperature_2m"),
            feelsLike = cur.getDouble("apparent_temperature"),
            humidity = cur.getInt("relative_humidity_2m"),
            windKmh = cur.getDouble("wind_speed_10m"),
            code = cur.getInt("weather_code"),
            isDay = cur.getInt("is_day") == 1,
            max = daily.getJSONArray("temperature_2m_max").getDouble(0),
            min = daily.getJSONArray("temperature_2m_min").getDouble(0),
            hours = hours,
            updatedAt = System.currentTimeMillis(),
        )
    }

    fun searchCity(query: String): List<Place> {
        val q = URLEncoder.encode(query.trim(), "UTF-8")
        val root = JSONObject(get("https://geocoding-api.open-meteo.com/v1/search?name=$q&count=8&language=en&format=json"))
        val arr = root.optJSONArray("results") ?: return emptyList()
        return (0 until arr.length()).map { i ->
            val o = arr.getJSONObject(i)
            Place(
                name = o.getString("name"),
                region = listOf(o.optString("admin1"), o.optString("country"))
                    .filter { it.isNotBlank() }.joinToString(", "),
                lat = o.getDouble("latitude"),
                lon = o.getDouble("longitude"),
            )
        }
    }
}
