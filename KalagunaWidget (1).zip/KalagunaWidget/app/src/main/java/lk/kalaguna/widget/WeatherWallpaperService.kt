package lk.kalaguna.widget

import android.content.SharedPreferences
import android.graphics.Canvas
import android.os.Handler
import android.os.Looper
import android.view.Choreographer
import android.service.wallpaper.WallpaperService
import android.view.SurfaceHolder

/**
 * Live wallpaper: the whole home screen becomes the live weather sky
 * (drifting clouds, rain falling from the very top to the bottom, lightning, snow, sun, moon, stars).
 * It follows the same city and weather as the widget, and stops drawing whenever it is hidden.
 */
class WeatherWallpaperService : WallpaperService() {

    override fun onCreateEngine(): Engine = SkyEngine()

    inner class SkyEngine : Engine(), SharedPreferences.OnSharedPreferenceChangeListener, Choreographer.FrameCallback {

        private val handler = Handler(Looper.getMainLooper())
        private val drawRunner = Runnable { startFrames() }
        private val choreographer = Choreographer.getInstance()
        private var framesRunning = false
        private lateinit var prefs: Prefs
        private var scene: SkyScene? = null
        private var visible = false
        private var lastFrame = 0L
        private var useHardware = true

        override fun onCreate(surfaceHolder: SurfaceHolder) {
            super.onCreate(surfaceHolder)
            setTouchEventsEnabled(false)
            prefs = Prefs(applicationContext)
            prefs.listen(this)
            scene = SkyScene(applicationContext).also { it.reload(prefs) }
            // The wallpaper needs fresh weather even when no widget is on the home screen.
            WeatherWorker.schedule(applicationContext)
            if (prefs.snapshot == null) WeatherWorker.refreshNow(applicationContext)
        }

        override fun onDestroy() {
            stopFrames()
            handler.removeCallbacks(drawRunner)
            prefs.unlisten(this)
            super.onDestroy()
        }

        override fun onSurfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) {
            super.onSurfaceChanged(holder, format, width, height)
            scene?.resize(width, height)
            scheduleNext(0)
        }

        override fun onSurfaceDestroyed(holder: SurfaceHolder) {
            visible = false
            stopFrames()
            handler.removeCallbacks(drawRunner)
            super.onSurfaceDestroyed(holder)
        }

        override fun onVisibilityChanged(isVisible: Boolean) {
            visible = isVisible
            if (isVisible) {
                lastFrame = 0L
                scene?.reload(prefs)
                // keep the weather fresh even if every widget was removed
                WeatherWorker.schedule(applicationContext)
                val snap = prefs.snapshot
                if (snap == null || System.currentTimeMillis() - snap.updatedAt > 45 * 60 * 1000L) {
                    WeatherWorker.refreshNow(applicationContext)
                }
                scheduleNext(0)
            } else {
                stopFrames()
                handler.removeCallbacks(drawRunner)
            }
        }

        override fun onOffsetsChanged(
            xOffset: Float, yOffset: Float, xOffsetStep: Float, yOffsetStep: Float,
            xPixelOffset: Int, yPixelOffset: Int,
        ) {
            scene?.pageOffset = xOffset
        }

        override fun onSharedPreferenceChanged(sp: SharedPreferences?, key: String?) {
            if (key == "snapshot") scene?.reload(prefs)
        }

        private fun scheduleNext(delayMs: Long) {
            handler.removeCallbacks(drawRunner)
            if (visible) handler.postDelayed(drawRunner, delayMs)
        }

        /** Draw in step with the screen refresh (vsync) for perfectly smooth motion. */
        private fun startFrames() {
            if (!visible || framesRunning) return
            framesRunning = true
            lastFrame = 0L
            choreographer.postFrameCallback(this)
        }

        private fun stopFrames() {
            framesRunning = false
            choreographer.removeFrameCallback(this)
        }

        override fun doFrame(frameTimeNanos: Long) {
            if (!framesRunning || !visible) {
                framesRunning = false
                return
            }
            drawFrame(frameTimeNanos)
            choreographer.postFrameCallback(this)
        }

        private fun drawFrame(frameTimeNanos: Long) {
            val s = scene ?: return
            val dt = if (lastFrame == 0L) 0.016f else ((frameTimeNanos - lastFrame) / 1e9f).coerceIn(0f, 0.1f)
            lastFrame = frameTimeNanos
            val holder = surfaceHolder
            var canvas: Canvas? = null
            try {
                canvas = if (useHardware) {
                    try {
                        holder.lockHardwareCanvas()
                    } catch (e: Exception) {
                        useHardware = false
                        holder.lockCanvas()
                    }
                } else {
                    holder.lockCanvas()
                }
                if (canvas != null) s.draw(canvas, dt) else if (useHardware) useHardware = false
            } catch (e: Exception) {
                // surface went away mid-frame; the next visibility change restarts drawing
            } finally {
                if (canvas != null) {
                    try {
                        holder.unlockCanvasAndPost(canvas)
                    } catch (e: Exception) {
                    }
                }
            }
        }
    }
}
