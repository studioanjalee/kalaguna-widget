package lk.kalaguna.widget

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.Build
import android.util.SizeF
import android.view.View
import android.widget.RemoteViews
import kotlin.math.roundToInt

/** Builds the widget's RemoteViews from the saved weather. */
object WidgetRenderer {

    private enum class Size(val layout: Int) {
        SMALL(R.layout.widget_weather_small),
        MEDIUM(R.layout.widget_weather_medium),
        LARGE(R.layout.widget_weather),
    }

    private val HOUR_IDS = arrayOf(
        intArrayOf(R.id.h1_time, R.id.h1_icon, R.id.h1_temp),
        intArrayOf(R.id.h2_time, R.id.h2_icon, R.id.h2_temp),
        intArrayOf(R.id.h3_time, R.id.h3_icon, R.id.h3_temp),
        intArrayOf(R.id.h4_time, R.id.h4_icon, R.id.h4_temp),
    )

    fun updateAll(context: Context) {
        val mgr = AppWidgetManager.getInstance(context)
        val ids = mgr.getAppWidgetIds(ComponentName(context, WeatherWidgetProvider::class.java))
        ids.forEach { mgr.updateAppWidget(it, viewsFor(context, mgr, it)) }
    }

    fun viewsFor(context: Context, mgr: AppWidgetManager, widgetId: Int): RemoteViews {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            // Android 12+: the launcher picks the layout that fits while the widget is resized.
            RemoteViews(
                mapOf(
                    SizeF(100f, 100f) to build(context, Size.SMALL),
                    SizeF(200f, 100f) to build(context, Size.MEDIUM),
                    SizeF(200f, 165f) to build(context, Size.LARGE),
                )
            )
        } else {
            val o = mgr.getAppWidgetOptions(widgetId)
            val w = o.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_WIDTH, 250)
            val h = o.getInt(AppWidgetManager.OPTION_APPWIDGET_MAX_HEIGHT, 180)
            build(
                context,
                when {
                    w < 200 -> Size.SMALL
                    h < 165 -> Size.MEDIUM
                    else -> Size.LARGE
                }
            )
        }
    }

    private fun build(context: Context, size: Size): RemoteViews {
        val prefs = Prefs(context)
        val en = prefs.english
        val snap = prefs.snapshot
        val rv = RemoteViews(context.packageName, size.layout)

        // Sky + animated layers
        val scene = Scene.fromCode(snap?.code ?: 2)
        val isDay = snap?.isDay ?: true
        val on = scene.layers(isDay)
        Scene.ALL_LAYERS.forEach { id -> rv.setViewVisibility(id, if (id in on) View.VISIBLE else View.GONE) }
        rv.setInt(android.R.id.background, "setBackgroundResource", scene.background(isDay))

        // Text
        rv.setTextViewText(R.id.city, prefs.cityLabel())
        rv.setTextViewText(R.id.lang_btn, Txt.langButton(en))
        rv.setTextViewText(R.id.temp, snap?.let { "${it.temp.roundToInt()}°" } ?: "--°")
        rv.setTextViewText(R.id.condition, snap?.let { Txt.condition(it.code, en) } ?: Txt.loading(en))
        rv.setTextViewText(R.id.details, snap?.let { Txt.details(it, en) } ?: Txt.noData(en))

        if (size == Size.LARGE) {
            rv.setViewVisibility(R.id.hourly, if (snap == null) View.INVISIBLE else View.VISIBLE)
            HOUR_IDS.forEachIndexed { i, ids ->
                val h = snap?.hours?.getOrNull(i)
                rv.setTextViewText(ids[0], h?.let { Txt.hour(it.hour, en) } ?: "")
                rv.setTextViewText(ids[2], h?.let { "${it.temp.roundToInt()}°" } ?: "")
                rv.setImageViewResource(ids[1], Scene.fromCode(h?.code ?: 0).icon(h?.isDay ?: true))
                rv.setViewVisibility(ids[1], if (h == null) View.INVISIBLE else View.VISIBLE)
            }
        }

        // Tap the widget -> open the app. ⟳ -> refresh now. EN/සිං -> switch language.
        rv.setOnClickPendingIntent(
            android.R.id.background,
            PendingIntent.getActivity(
                context, 0, Intent(context, MainActivity::class.java),
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
        )
        rv.setOnClickPendingIntent(R.id.refresh, broadcast(context, 1, WeatherWidgetProvider.ACTION_REFRESH))
        rv.setOnClickPendingIntent(R.id.lang_btn, broadcast(context, 2, WeatherWidgetProvider.ACTION_TOGGLE_LANG))
        return rv
    }

    private fun broadcast(context: Context, code: Int, action: String): PendingIntent =
        PendingIntent.getBroadcast(
            context, code,
            Intent(context, WeatherWidgetProvider::class.java).setAction(action),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
}
