"""Writes the three widget layouts (small / medium / large) with the animated layers.

Usage: python3 tools/build_layouts.py app/src/main/res
Layer order (bottom -> top): sky, stars, sun/moon, far clouds, back clouds & rain,
TEXT, front clouds/rain/snow/fog, lightning flash. So clouds really pass between the letters.
"""
import os
import sys

RES = sys.argv[1]
L = os.path.join(RES, "layout")
os.makedirs(L, exist_ok=True)

# (view id, drawable, duration ms)  - duration only matters for sliding/rotating layers
BACK = [
    ("l_stars", "anim_stars", 0),
    ("CELESTIAL", None, 0),
    ("l_wisp", "layer_wisp", 160000),
    ("l_white_far", "layer_white_far", 150000),
    ("l_grey_far", "layer_grey_far", 150000),
    ("l_dark_far", "layer_dark_far", 150000),
    ("l_night_far", "layer_night_far", 150000),
    ("l_fog_back", "layer_fog_back", 120000),
    ("l_fog_night", "layer_fog_night", 110000),
    ("l_white_back", "layer_white_back", 95000),
    ("l_grey_back", "layer_grey_back", 95000),
    ("l_dark_back", "layer_dark_back", 95000),
    ("l_night_back", "layer_night_back", 95000),
    ("l_rain_back", "layer_rain_back", 520),
    ("l_snow_back", "layer_snow_back", 16000),
]
FRONT = [
    ("l_white_front", "layer_white_front", 70000),
    ("l_grey_front", "layer_grey_front", 70000),
    ("l_dark_front", "layer_dark_front", 70000),
    ("l_night_front", "layer_night_front", 70000),
    ("l_fog_front", "layer_fog_front", 90000),
    ("l_rain_front", "layer_rain_front", 330),
    ("l_snow_front", "layer_snow_front", 9000),
    ("l_lightning", "anim_lightning", 0),
]


def pb(vid, drawable, ms, w="match_parent", h="match_parent", extra=""):
    dur = f'\n        android:indeterminateDuration="{ms}"' if ms else ""
    return f'''
    <ProgressBar
        android:id="@+id/{vid}"
        style="@android:style/Widget.ProgressBar"
        android:layout_width="{w}"
        android:layout_height="{h}"{extra}
        android:visibility="gone"
        android:indeterminate="true"
        android:indeterminateOnly="false"
        android:indeterminateDrawable="@drawable/{drawable}"
        android:indeterminateBehavior="repeat"{dur}
        android:interpolator="@android:anim/linear_interpolator"
        android:minWidth="0dp"
        android:minHeight="0dp"
        android:maxWidth="2000dp"
        android:maxHeight="2000dp"
        android:mirrorForRtl="false" />'''


def celestial(size, gravity, mt, me, mx=""):
    margins = f'\n        android:layout_gravity="{gravity}"\n        android:layout_marginTop="{mt}dp"\n        android:layout_marginEnd="{me}dp"{mx}'
    sun = pb("l_sun", "layer_sun", 60000, f"{size}dp", f"{size}dp", margins)
    moon = f'''
    <ImageView
        android:id="@+id/l_moon"
        android:layout_width="{int(size * 0.87)}dp"
        android:layout_height="{int(size * 0.87)}dp"{margins}
        android:visibility="gone"
        android:scaleType="fitCenter"
        android:src="@drawable/img_moon"
        android:importantForAccessibility="no" />'''
    return sun + moon


def layers(group, cel):
    out = []
    for vid, dr, ms in group:
        out.append(cel if vid == "CELESTIAL" else pb(vid, dr, ms))
    return "".join(out)


def buttons(gravity_attrs=""):
    return f'''
        <TextView
            android:id="@+id/lang_btn"
            android:layout_width="wrap_content"
            android:layout_height="26dp"
            android:minWidth="34dp"
            android:gravity="center"
            android:paddingStart="9dp"
            android:paddingEnd="9dp"
            android:background="@drawable/pill_bg"
            android:text="EN"
            android:textColor="#FFFFFFFF"
            android:textSize="11sp"
            android:fontFamily="sans-serif-medium" />
        <ImageView
            android:id="@+id/refresh"
            android:layout_width="26dp"
            android:layout_height="26dp"
            android:layout_marginStart="6dp"
            android:padding="6dp"
            android:background="@drawable/pill_bg"
            android:src="@drawable/ic_refresh"
            android:contentDescription="@string/refresh" />'''


def root(inner_back, content, inner_front):
    return f'''<?xml version="1.0" encoding="utf-8"?>
<FrameLayout xmlns:android="http://schemas.android.com/apk/res/android"
    android:id="@android:id/background"
    android:layout_width="match_parent"
    android:layout_height="match_parent"
    android:background="@drawable/bg_clear_day"
    android:clipToOutline="true"
    android:theme="@style/WidgetTheme">
{inner_back}
{content}
{inner_front}
</FrameLayout>
'''


def hour_col(i):
    return f'''
            <LinearLayout
                android:layout_width="0dp"
                android:layout_height="wrap_content"
                android:layout_weight="1"
                android:gravity="center_horizontal"
                android:orientation="vertical">
                <TextView android:id="@+id/h{i}_time" style="@style/WidgetText.Small" android:textSize="10sp" android:text="" />
                <ImageView
                    android:id="@+id/h{i}_icon"
                    android:layout_width="26dp"
                    android:layout_height="26dp"
                    android:src="@drawable/ic_w_clear_day"
                    android:importantForAccessibility="no" />
                <TextView android:id="@+id/h{i}_temp" style="@style/WidgetText.Hour" android:text="" />
            </LinearLayout>'''


TOP_ROW = f'''
        <LinearLayout
            android:layout_width="match_parent"
            android:layout_height="wrap_content"
            android:gravity="center_vertical"
            android:orientation="horizontal">
            <ImageView
                android:layout_width="13dp"
                android:layout_height="13dp"
                android:layout_marginEnd="3dp"
                android:src="@drawable/ic_pin"
                android:importantForAccessibility="no" />
            <TextView
                android:id="@+id/city"
                style="@style/WidgetText.City"
                android:layout_width="0dp"
                android:layout_weight="1"
                android:text="@string/default_city" />{buttons()}
        </LinearLayout>'''

TEMP_BLOCK = '''
        <LinearLayout
            android:layout_width="match_parent"
            android:layout_height="wrap_content"
            android:gravity="center_vertical"
            android:orientation="horizontal">
            <TextView
                android:id="@+id/temp"
                style="@style/WidgetText.Temp"
                android:textSize="{temp_sp}sp"
                android:text="--°" />
            <LinearLayout
                android:layout_width="0dp"
                android:layout_height="wrap_content"
                android:layout_weight="1"
                android:layout_marginStart="10dp"
                android:orientation="vertical">
                <TextView
                    android:id="@+id/condition"
                    style="@style/WidgetText.Condition"
                    android:text="@string/loading" />
                <TextView
                    android:id="@+id/details"
                    style="@style/WidgetText.Small"
                    android:layout_marginTop="2dp"
                    android:maxLines="2"
                    android:text="" />
            </LinearLayout>
        </LinearLayout>'''


def large():
    content = f'''
    <LinearLayout
        android:layout_width="match_parent"
        android:layout_height="match_parent"
        android:orientation="vertical"
        android:paddingStart="16dp"
        android:paddingTop="12dp"
        android:paddingEnd="12dp"
        android:paddingBottom="10dp">
{TOP_ROW}
        <FrameLayout android:layout_width="match_parent" android:layout_height="0dp" android:layout_weight="1" />
{TEMP_BLOCK.format(temp_sp=50)}
        <FrameLayout android:layout_width="match_parent" android:layout_height="0dp" android:layout_weight="1" />
        <LinearLayout
            android:id="@+id/hourly"
            android:layout_width="match_parent"
            android:layout_height="wrap_content"
            android:background="@drawable/hourly_bg"
            android:paddingTop="5dp"
            android:paddingBottom="5dp"
            android:orientation="horizontal">{"".join(hour_col(i) for i in range(1, 5))}
        </LinearLayout>
    </LinearLayout>'''
    return root(layers(BACK, celestial(150, "top|end", -34, -30)), content, layers(FRONT, ""))


def medium():
    content = f'''
    <LinearLayout
        android:layout_width="match_parent"
        android:layout_height="match_parent"
        android:orientation="vertical"
        android:paddingStart="16dp"
        android:paddingTop="12dp"
        android:paddingEnd="12dp"
        android:paddingBottom="12dp">
{TOP_ROW}
        <FrameLayout android:layout_width="match_parent" android:layout_height="0dp" android:layout_weight="1" />
{TEMP_BLOCK.format(temp_sp=46)}
    </LinearLayout>'''
    return root(layers(BACK, celestial(130, "top|end", -30, -26)), content, layers(FRONT, ""))


def small():
    content = f'''
    <LinearLayout
        android:layout_width="wrap_content"
        android:layout_height="wrap_content"
        android:layout_gravity="top|start"
        android:layout_marginStart="10dp"
        android:layout_marginTop="10dp"
        android:orientation="horizontal">{buttons()}
    </LinearLayout>

    <LinearLayout
        android:layout_width="match_parent"
        android:layout_height="wrap_content"
        android:layout_gravity="bottom|start"
        android:orientation="vertical"
        android:paddingStart="12dp"
        android:paddingEnd="10dp"
        android:paddingBottom="10dp">
        <TextView
            android:id="@+id/temp"
            style="@style/WidgetText.Temp"
            android:textSize="38sp"
            android:text="--°" />
        <TextView
            android:id="@+id/condition"
            style="@style/WidgetText.Condition"
            android:textSize="12sp"
            android:text="@string/loading" />
        <TextView
            android:id="@+id/details"
            style="@style/WidgetText.Small"
            android:visibility="gone"
            android:text="" />
        <LinearLayout
            android:layout_width="match_parent"
            android:layout_height="wrap_content"
            android:layout_marginTop="2dp"
            android:gravity="center_vertical"
            android:orientation="horizontal">
            <ImageView
                android:layout_width="11dp"
                android:layout_height="11dp"
                android:layout_marginEnd="2dp"
                android:src="@drawable/ic_pin"
                android:importantForAccessibility="no" />
            <TextView
                android:id="@+id/city"
                style="@style/WidgetText.City"
                android:textSize="11sp"
                android:layout_width="0dp"
                android:layout_weight="1"
                android:text="@string/default_city" />
        </LinearLayout>
    </LinearLayout>'''
    return root(layers(BACK, celestial(120, "top|end", -26, -26)), content, layers(FRONT, ""))


for name, fn in (("widget_weather", large), ("widget_weather_medium", medium), ("widget_weather_small", small)):
    with open(os.path.join(L, name + ".xml"), "w") as f:
        f.write(fn())
print("layouts done")
