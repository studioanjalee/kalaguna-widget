"""Renders the realistic weather art for the widget as PNG files.

Usage: python3 tools/render_art.py app/src/main/res
Everything is procedural (numpy + PIL), so it can be tweaked and re-rendered.
"""
import math
import os
import sys

import numpy as np
from PIL import Image, ImageDraw, ImageFilter
from scipy.ndimage import gaussian_filter, zoom

RES = sys.argv[1]
RNG = np.random.default_rng(7)
DENS = {"xhdpi": 2.0, "xxhdpi": 3.0}


def save(arr, name, bucket):
    """arr: float RGBA (H, W, 4) in 0..1 (straight alpha)."""
    d = os.path.join(RES, f"drawable-{bucket}")
    os.makedirs(d, exist_ok=True)
    img = Image.fromarray((np.clip(arr, 0, 1) * 255 + 0.5).astype(np.uint8), "RGBA")
    img.save(os.path.join(d, name + ".png"), optimize=True)
    return img


def smoothstep(a, b, x):
    t = np.clip((x - a) / (b - a), 0, 1)
    return t * t * (3 - 2 * t)


def fbm(h, w, scales=(64, 32, 16, 8, 4), rng=RNG):
    out = np.zeros((h, w))
    amp, tot = 1.0, 0.0
    for s in scales:
        gh, gw = max(2, h // s + 2), max(2, w // s + 2)
        g = rng.standard_normal((gh, gw))
        z = zoom(g, (h / gh * 1.02 + 0.01, w / gw * 1.02 + 0.01), order=3)[:h, :w]
        out += z * amp
        tot += amp
        amp *= 0.55
    out /= tot
    return out / (np.abs(out).max() + 1e-9)


def rgba(rgb, a):
    out = np.zeros(a.shape + (4,))
    out[..., :3] = rgb
    out[..., 3] = a
    return out


def over(dst, src):
    """Alpha-composite src over dst (both straight-alpha float RGBA)."""
    sa, da = src[..., 3:4], dst[..., 3:4]
    oa = sa + da * (1 - sa)
    oc = (src[..., :3] * sa + dst[..., :3] * da * (1 - sa)) / np.maximum(oa, 1e-6)
    return np.concatenate([oc, oa], axis=-1)


def hexc(h):
    h = h.lstrip("#")
    return np.array([int(h[i:i + 2], 16) / 255 for i in (0, 2, 4)])


# ---------------------------------------------------------------- clouds
def cloud(w, h, seed, puffs=5, flat=True, fluff=1.0, wispy=False):
    """Cumulus made of lit spherical puffs (cauliflower look) with fluffy cotton edges."""
    rng = np.random.default_rng(seed)
    yy, xx = np.mgrid[0:h, 0:w].astype(float)
    base_y = h * 0.84
    blobs = []  # (cx, cy, r) drawn in order: back/top first, base last
    for i in range(puffs):
        t = (i + 0.5) / puffs
        mid = 1 - abs(t - 0.5) * 1.7
        r = h * (0.20 + 0.20 * mid) * rng.uniform(0.85, 1.12)
        cx = w * (0.20 + 0.60 * t) + rng.uniform(-0.04, 0.04) * w
        cy = base_y - r * 0.85 - h * 0.14 * mid
        r = min(r, (cy - h * 0.03) / 1.05)  # keep the top inside the canvas
        blobs.append((cx, cy, r))
        for _ in range(int(3 * fluff)):  # little knobs on top of each big puff
            a = rng.uniform(math.pi * 1.15, math.pi * 1.85)
            sr = r * rng.uniform(0.32, 0.5)
            kx, ky = cx + math.cos(a) * r * 0.72, cy + math.sin(a) * r * 0.72
            sr = min(sr, (ky - h * 0.03) / 1.05)
            if sr > 2:
                blobs.append((kx, ky, sr))
    n_base = 5
    for i in range(n_base):
        cx = w * (0.16 + 0.68 * i / (n_base - 1)) + rng.uniform(-0.02, 0.02) * w
        r = h * rng.uniform(0.24, 0.32) * (0.75 if i in (0, n_base - 1) else 1.0)
        r = min(r, cx - w * 0.03, w * 0.97 - cx)  # stay inside the canvas sideways
        blobs.append((cx, base_y - r * 0.45 + rng.uniform(-0.03, 0.03) * h, r))

    noise = fbm(h, w, (24, 12, 6, 3), rng)
    fibre = fbm(h, w, (4, 2), rng)
    L = np.array([-0.35, -0.75, 0.55]); L /= np.linalg.norm(L)
    amb, lightc = hexc("#9DABC3"), hexc("#FFFFFF")
    out = np.zeros((h, w, 4))
    for (cx, cy, r) in blobs:
        dx, dy = (xx - cx) / r, (yy - cy) / r
        d2 = dx * dx + dy * dy
        d = np.sqrt(d2) + noise * 0.10 * fluff + fibre * 0.035
        a = smoothstep(1.0, 0.80, d)
        if not a.any():
            continue
        z = np.sqrt(np.clip(1 - d2, 0, 1))
        diff = np.clip(dx * L[0] + dy * L[1] + z * L[2], 0, 1)
        light = 0.30 + 0.70 * diff ** 0.75
        rim = smoothstep(0.6, 1.0, np.sqrt(d2)) * (0.25 if cy < base_y - h * 0.3 else 0.08)  # light scatters through thin edges
        lv = np.clip(light + rim, 0, 1)
        col = amb[None, None, :] * (1 - lv[..., None]) + lightc[None, None, :] * lv[..., None]
        out = over(out, rgba(col, a))
    # darker, flatter underside like real cumulus
    v = smoothstep(h * 0.35, base_y, yy)
    out[..., :3] *= (1 - v[..., None] * 0.18)
    if flat:
        out[..., 3] *= smoothstep(base_y + h * 0.02, base_y - h * 0.05, yy + noise * h * 0.03)
    out[..., :3] *= (1 + fibre[..., None] * 0.03)
    out[..., 3] = gaussian_filter(out[..., 3], 0.7)
    if wispy:
        out[..., 3] = gaussian_filter(out[..., 3], h * 0.05) * smoothstep(-0.6, 0.6, noise) * 1.2
    return np.clip(out, 0, 1)


def crop_alpha(arr, pad=4):
    a = arr[..., 3]
    ys, xs = np.where(a > 0.01)
    y0, y1 = max(0, ys.min() - pad), min(a.shape[0], ys.max() + pad)
    x0, x1 = max(0, xs.min() - pad), min(a.shape[1], xs.max() + pad)
    return arr[y0:y1, x0:x1]


def make_clouds():
    s = DENS["xxhdpi"]
    specs = [  # name, w dp, h dp, seed, puffs
        ("cloud_a", 230, 130, 11, 5),
        ("cloud_b", 190, 110, 23, 4),
        ("cloud_c", 260, 125, 37, 6),
        ("cloud_d", 150, 90, 51, 3),
    ]
    out = {}
    for name, wd, hd, seed, puffs in specs:
        arr = cloud(int(wd * s), int(hd * s), seed, puffs)
        out[name] = arr
        save(arr, name, "xxhdpi")
    s2 = DENS["xhdpi"]
    ww, wh = int(300 * s2), int(70 * s2)
    yy, xx = np.mgrid[0:wh, 0:ww].astype(float)
    streak = zoom(np.random.default_rng(77).standard_normal((6, 40)), (wh / 6, ww / 40), order=3)[:wh, :ww]
    streak = gaussian_filter(streak, (6, 30))
    band = np.exp(-((yy - wh * 0.5) / (wh * 0.22)) ** 2)
    wa = np.clip(band * smoothstep(-0.6, 0.8, streak / (np.abs(streak).max() + 1e-6) + fbm(wh, ww, (30, 15, 8)) * 0.25), 0, 1)
    wa = gaussian_filter(wa, 3)
    wa *= smoothstep(0, ww * 0.2, xx) * smoothstep(ww, ww * 0.8, xx)
    w = rgba(hexc("#FFFFFF"), wa * 0.7)
    out["cloud_wisp"] = w
    save(w, "cloud_wisp", "xhdpi")
    return out


# ---------------------------------------------------------------- fog
def make_fog():
    s = DENS["xhdpi"]
    w, h = int(440 * s), int(90 * s)
    yy, xx = np.mgrid[0:h, 0:w].astype(float)
    n = fbm(h, w, (160, 80, 40, 20))
    band = np.exp(-((yy - h * 0.5) / (h * 0.24)) ** 2)
    a = np.clip(band * (0.55 + n * 0.45), 0, 1)
    a *= smoothstep(0, w * 0.18, xx) * smoothstep(w, w * 0.82, xx)
    a = gaussian_filter(a, 3)
    save(rgba(hexc("#F2F5F8"), a * 0.85), "fog_band", "xhdpi")


# ---------------------------------------------------------------- sun
def radial(size, cx, cy):
    yy, xx = np.mgrid[0:size, 0:size].astype(float)
    return np.hypot(xx - cx, yy - cy), np.arctan2(yy - cy, xx - cx)


def make_sun():
    # glow (static) – 260dp @ xhdpi
    s = DENS["xhdpi"]
    S = int(260 * s)
    r, ang = radial(S, S / 2, S / 2)
    R = S / 2
    g = np.exp(-(r / (R * 0.38)) ** 2) * 0.75 + np.exp(-(r / (R * 0.75)) ** 2) * 0.35
    col = np.ones((S, S, 3)) * hexc("#FFE08A")
    col = col * (1 - np.clip(r / R, 0, 1)[..., None] * 0.3) + hexc("#FFB347") * np.clip(r / R, 0, 1)[..., None] * 0.3
    save(rgba(col, np.clip(g, 0, 1) * smoothstep(R, R * 0.8, r)), "sun_glow", "xhdpi")

    # rays (two layers, rotate opposite ways)
    for name, seed, count, alpha in (("sun_rays", 3, 14, 0.42), ("sun_rays2", 9, 9, 0.28)):
        rng = np.random.default_rng(seed)
        a = np.zeros((S, S))
        for i in range(count):
            th = 2 * math.pi * i / count + rng.uniform(-0.15, 0.15)
            length = R * rng.uniform(0.62, 0.98)
            width = math.radians(rng.uniform(2.5, 6.5))
            d = np.angle(np.exp(1j * (ang - th)))
            beam = np.exp(-(d / width) ** 2) * smoothstep(length, R * 0.18, r) * smoothstep(R * 0.12, R * 0.3, r)
            a = np.maximum(a, beam * rng.uniform(0.6, 1.0))
        a = gaussian_filter(a, 2.2) * alpha
        save(rgba(hexc("#FFF0B0"), np.clip(a, 0, 1)), name, "xhdpi")

    # core – 80dp @ xxhdpi
    s = DENS["xxhdpi"]
    S = int(80 * s)
    r, _ = radial(S, S / 2, S / 2)
    R = S * 0.36
    t = np.clip(r / R, 0, 1)
    col = np.zeros((S, S, 3))
    c0, c1, c2 = hexc("#FFFEF4"), hexc("#FFE36E"), hexc("#FFA726")
    col += np.where(t[..., None] < 0.55,
                    c0 * (1 - t[..., None] / 0.55) + c1 * (t[..., None] / 0.55),
                    c1 * (1 - (t[..., None] - 0.55) / 0.45) + c2 * ((t[..., None] - 0.55) / 0.45))
    disc = smoothstep(R + 1.5, R - 1.5, r)
    bloom = np.exp(-((r - R) / (S * 0.09)) ** 2) * (r > R) * 0.85
    a = np.clip(disc + bloom, 0, 1)
    col = np.where((r > R)[..., None], hexc("#FFE9A0"), col)
    save(rgba(col, a), "sun_core", "xxhdpi")


# ---------------------------------------------------------------- moon
def make_moon():
    s = DENS["xxhdpi"]
    S = int(84 * s)
    r, _ = radial(S, S / 2, S / 2)
    R = S * 0.36
    yy, xx = np.mgrid[0:S, 0:S].astype(float)
    n = fbm(S, S, (40, 20, 10, 5))
    maria = smoothstep(0.05, 0.45, gaussian_filter(fbm(S, S, (60, 30)), 3))
    base = hexc("#F5F1E3")
    dark = hexc("#BDB8A8")
    col = base * (1 - maria[..., None] * 0.55) + dark * (maria[..., None] * 0.55)
    col *= (1 + n[..., None] * 0.04)
    rng = np.random.default_rng(5)
    for _ in range(14):  # craters
        cx, cy = S / 2 + rng.uniform(-0.8, 0.8) * R, S / 2 + rng.uniform(-0.8, 0.8) * R
        cr = rng.uniform(0.04, 0.12) * R
        d = np.hypot(xx - cx, yy - cy)
        col *= (1 - 0.12 * smoothstep(cr, cr * 0.6, d))[..., None]
        rim = np.exp(-((d - cr) / (cr * 0.25)) ** 2) * ((yy - cy) < 0)
        col += rim[..., None] * 0.05
    limb = np.clip(1 - (r / R) ** 4 * 0.35, 0, 1)
    col *= limb[..., None]
    # gentle terminator shading on the lower-right (gibbous look)
    shade = smoothstep(-0.2, 1.0, ((xx - S / 2) * 0.8 + (yy - S / 2) * 0.4) / R)
    col *= (1 - shade[..., None] * 0.45)
    disc = smoothstep(R + 1.5, R - 1.5, r)
    halo = np.exp(-((r - R) / (S * 0.07)) ** 2) * (r > R) * 0.45
    col = np.where((r > R)[..., None], hexc("#DCE6FF"), col)
    save(rgba(np.clip(col, 0, 1), np.clip(disc + halo, 0, 1)), "moon", "xxhdpi")

    s = DENS["xhdpi"]
    S = int(220 * s)
    r, _ = radial(S, S / 2, S / 2)
    g = np.exp(-(r / (S * 0.22)) ** 2) * 0.5
    save(rgba(hexc("#CFDBFF"), g * smoothstep(S / 2, S * 0.4, r)), "moon_glow", "xhdpi")


def make_star():
    s = DENS["xxhdpi"]
    S = int(18 * s)
    yy, xx = np.mgrid[0:S, 0:S].astype(float)
    dx, dy = xx - S / 2 + 0.5, yy - S / 2 + 0.5
    r = np.hypot(dx, dy)
    core = np.exp(-(r / (S * 0.06)) ** 2)
    glow = np.exp(-(r / (S * 0.18)) ** 2) * 0.45
    spikes = (np.exp(-(dx / 1.1) ** 2) + np.exp(-(dy / 1.1) ** 2)) * np.exp(-(r / (S * 0.42)) ** 2) * 0.7
    a = np.clip(core + glow + spikes, 0, 1) * smoothstep(S / 2, S * 0.42, r)
    save(rgba(hexc("#F4F7FF"), a), "star", "xxhdpi")


# ---------------------------------------------------------------- rain
def stamp(canvas_a, canvas_c, piece_a, piece_c, x, y, wrap=True):
    """Additive-ish stamp with wrap-around so tiles repeat seamlessly."""
    H, W = canvas_a.shape
    ph, pw = piece_a.shape
    for oy in ((-H, 0, H) if wrap else (0,)):
        for ox in ((-W, 0, W) if wrap else (0,)):
            x0, y0 = int(x + ox), int(y + oy)
            xa, ya = max(0, x0), max(0, y0)
            xb, yb = min(W, x0 + pw), min(H, y0 + ph)
            if xa >= xb or ya >= yb:
                continue
            pa = piece_a[ya - y0:yb - y0, xa - x0:xb - x0]
            pc = piece_c[ya - y0:yb - y0, xa - x0:xb - x0]
            ca = canvas_a[ya:yb, xa:xb]
            na = pa + ca * (1 - pa)
            canvas_c[ya:yb, xa:xb] = (pc * pa[..., None] + canvas_c[ya:yb, xa:xb] * (ca * (1 - pa))[..., None]) / np.maximum(na, 1e-6)[..., None]
            canvas_a[ya:yb, xa:xb] = na


def drop_piece(length, width, s, alpha):
    L, Wp = int(length * s), max(3, int(width * s * 3))
    yy, xx = np.mgrid[0:L, 0:Wp].astype(float)
    t = yy / max(L - 1, 1)
    core = np.exp(-((xx - Wp / 2 + 0.5) / (width * s * 0.45)) ** 2)
    a = core * (t ** 1.6) * alpha
    head = np.exp(-(((yy - L * 0.92) / (width * s * 0.9)) ** 2 + ((xx - Wp / 2 + 0.5) / (width * s * 0.6)) ** 2))
    a = np.clip(a + head * alpha * 0.3, 0, 1)
    c = np.ones((L, Wp, 3)) * hexc("#E3F1FF")
    return a, c


def make_rain():
    s = DENS["xhdpi"]
    for name, n, lmin, lmax, wmin, wmax, amin, amax, seed in (
        ("rain_back", 26, 10, 18, 0.9, 1.3, 0.35, 0.6, 1),
        ("rain_front", 12, 18, 30, 1.4, 2.0, 0.55, 0.85, 2),
    ):
        rng = np.random.default_rng(seed)
        T = int(200 * s)
        A = np.zeros((T, T))
        C = np.ones((T, T, 3))
        for _ in range(n):
            pa, pc = drop_piece(rng.uniform(lmin, lmax), rng.uniform(wmin, wmax), s, rng.uniform(amin, amax))
            stamp(A, C, pa, pc, rng.uniform(0, T), rng.uniform(0, T))
        save(rgba(C, A), name, "xhdpi")


# ---------------------------------------------------------------- snow
def flake_piece(size_px, rng):
    S = int(size_px * 2.2) | 1
    img = Image.new("L", (S, S), 0)
    d = ImageDraw.Draw(img)
    c = S / 2
    R = size_px / 2
    lw = max(1, int(size_px / 14))
    for k in range(6):
        a = k * math.pi / 3 + rng.uniform(0, 0.05)
        ex, ey = c + math.cos(a) * R, c + math.sin(a) * R
        d.line([(c, c), (ex, ey)], fill=255, width=lw)
        for f in (0.45, 0.7):
            bx, by = c + math.cos(a) * R * f, c + math.sin(a) * R * f
            for sgn in (-1, 1):
                b = a + sgn * math.pi / 4
                d.line([(bx, by), (bx + math.cos(b) * R * 0.3, by + math.sin(b) * R * 0.3)], fill=255, width=lw)
    d.ellipse([c - lw * 1.5, c - lw * 1.5, c + lw * 1.5, c + lw * 1.5], fill=255)
    sharp = np.asarray(img, dtype=float) / 255
    glow = gaussian_filter(sharp, size_px * 0.08) * 1.6
    a = np.clip(sharp * 0.95 + glow * 0.5, 0, 1)
    return a, np.ones((S, S, 3)) * hexc("#FFFFFF")


def dot_piece(size_px, alpha):
    S = int(size_px * 3) | 1
    yy, xx = np.mgrid[0:S, 0:S].astype(float)
    r = np.hypot(xx - S / 2, yy - S / 2)
    a = np.exp(-(r / (size_px * 0.5)) ** 2) * alpha
    return np.clip(a, 0, 1), np.ones((S, S, 3))


def make_snow():
    s = DENS["xhdpi"]
    T = int(200 * s)
    rng = np.random.default_rng(4)
    A, C = np.zeros((T, T)), np.ones((T, T, 3))
    for _ in range(30):
        pa, pc = dot_piece(rng.uniform(2.0, 4.0) * s, rng.uniform(0.5, 0.9))
        stamp(A, C, pa, pc, rng.uniform(0, T), rng.uniform(0, T))
    save(rgba(C, A), "snow_back", "xhdpi")
    A, C = np.zeros((T, T)), np.ones((T, T, 3))
    for _ in range(7):
        pa, pc = flake_piece(rng.uniform(9, 15) * s, rng)
        stamp(A, C, pa, pc, rng.uniform(0, T), rng.uniform(0, T))
    for _ in range(8):
        pa, pc = dot_piece(rng.uniform(3, 5) * s, 0.95)
        stamp(A, C, pa, pc, rng.uniform(0, T), rng.uniform(0, T))
    save(rgba(C, A), "snow_front", "xhdpi")


# ---------------------------------------------------------------- lightning
def make_bolt():
    s = DENS["xxhdpi"]
    W, H = int(90 * s), int(160 * s)
    rng = np.random.default_rng(12)

    def jag(p0, p1, depth, spread):
        if depth == 0:
            return [p0, p1]
        mx = (p0[0] + p1[0]) / 2 + rng.uniform(-spread, spread)
        my = (p0[1] + p1[1]) / 2 + rng.uniform(-spread, spread) * 0.3
        return jag(p0, (mx, my), depth - 1, spread / 2)[:-1] + jag((mx, my), p1, depth - 1, spread / 2)

    main = jag((W * 0.55, 0), (W * 0.42, H * 0.97), 6, W * 0.28)
    branches = []
    for idx in (len(main) // 4, len(main) // 2, int(len(main) * 0.68)):
        p = main[idx]
        end = (p[0] + rng.choice([-1, 1]) * W * rng.uniform(0.2, 0.38), p[1] + H * rng.uniform(0.12, 0.22))
        branches.append(jag(p, end, 4, W * 0.08))
    core = Image.new("L", (W, H), 0)
    d = ImageDraw.Draw(core)
    d.line(main, fill=255, width=int(2.4 * s), joint="curve")
    for b in branches:
        d.line(b, fill=200, width=int(1.2 * s), joint="curve")
    c = np.asarray(core, dtype=float) / 255
    g1 = gaussian_filter(c, 2.5 * s) * 2.5
    g2 = gaussian_filter(c, 7 * s) * 3.0
    a = np.clip(c + g1 * 0.8 + g2 * 0.6, 0, 1)
    col = np.ones((H, W, 3)) * hexc("#E8E4FF")
    col = col * (1 - c[..., None]) + c[..., None]  # white-hot core
    save(rgba(col, a), "bolt", "xxhdpi")


# ---------------------------------------------------------------- composite icons
def paste(dst, src, cx, cy, width):
    """Paste RGBA float src resized to `width` px, centred at (cx, cy) onto dst."""
    img = Image.fromarray((np.clip(src, 0, 1) * 255).astype(np.uint8), "RGBA")
    w = max(1, int(width))
    h = max(1, int(img.height * w / img.width))
    img = img.resize((w, h), Image.LANCZOS)
    layer = np.zeros_like(dst)
    a = np.asarray(img, dtype=float) / 255
    x0, y0 = int(cx - w / 2), int(cy - h / 2)
    H, W = dst.shape[:2]
    xa, ya, xb, yb = max(0, x0), max(0, y0), min(W, x0 + w), min(H, y0 + h)
    if xa < xb and ya < yb:
        layer[ya:yb, xa:xb] = a[ya - y0:yb - y0, xa - x0:xb - x0]
    return over(dst, layer)


def load(name, bucket):
    return np.asarray(Image.open(os.path.join(RES, f"drawable-{bucket}", name + ".png")), dtype=float) / 255


def make_icons(clouds):
    s = DENS["xxhdpi"]
    S = int(48 * s)
    sun_core, sun_glow, rays = load("sun_core", "xxhdpi"), load("sun_glow", "xhdpi"), load("sun_rays", "xhdpi")
    moon, bolt = load("moon", "xxhdpi"), load("bolt", "xxhdpi")
    grey = clouds["cloud_a"].copy()
    grey[..., :3] *= hexc("#8E9AAE")
    dark = clouds["cloud_a"].copy()
    dark[..., :3] *= hexc("#6B7488")

    def sun(dst, cx, cy, size):  # size = core diameter-ish in px
        dst = paste(dst, sun_glow, cx, cy, size * 1.75)
        dst = paste(dst, rays, cx, cy, size * 1.75)
        return paste(dst, sun_core, cx, cy, size * 1.4)

    def blank():
        return np.zeros((S, S, 4))

    def drops(dst, n=3, colr="#9FD4FF"):
        img = Image.new("RGBA", (S, S))
        d = ImageDraw.Draw(img)
        for i in range(n):
            x = S * (0.32 + 0.18 * i)
            y = S * (0.70 + 0.06 * (i % 2))
            d.line([(x + 4, y), (x - 2, y + S * 0.16)], fill=colr + "FF", width=int(S * 0.045))
        return over(dst, np.asarray(img.filter(ImageFilter.GaussianBlur(0.6)), dtype=float) / 255)

    def flakes(dst):
        img = Image.new("RGBA", (S, S))
        d = ImageDraw.Draw(img)
        for i in range(3):
            x, y = S * (0.32 + 0.18 * i), S * (0.78 + 0.07 * (i % 2))
            r = S * 0.055
            for k in range(3):
                a = k * math.pi / 3
                d.line([(x - math.cos(a) * r, y - math.sin(a) * r), (x + math.cos(a) * r, y + math.sin(a) * r)],
                       fill="#FFFFFFFF", width=max(2, int(S * 0.025)))
        return over(dst, np.asarray(img, dtype=float) / 255)

    icons = {}
    icons["ic_w_clear_day"] = sun(blank(), S / 2, S / 2, S * 0.56)
    m = paste(blank(), load("moon_glow", "xhdpi"), S / 2, S / 2, S * 0.98)
    icons["ic_w_clear_night"] = paste(m, moon, S / 2, S / 2, S * 0.9)
    c = sun(blank(), S * 0.38, S * 0.38, S * 0.40)
    icons["ic_w_partly_day"] = paste(c, clouds["cloud_a"], S * 0.56, S * 0.64, S * 0.80)
    c = paste(blank(), moon, S * 0.36, S * 0.36, S * 0.62)
    icons["ic_w_partly_night"] = paste(c, clouds["cloud_a"], S * 0.56, S * 0.64, S * 0.80)
    c = paste(blank(), grey, S * 0.40, S * 0.40, S * 0.70)
    icons["ic_w_cloudy"] = paste(c, clouds["cloud_b"], S * 0.55, S * 0.60, S * 0.86)
    c = drops(blank())
    icons["ic_w_rain"] = paste(c, grey, S * 0.5, S * 0.42, S * 0.92)
    c = drops(blank(), 3, "#B9C8FF")
    c = paste(c, bolt, S * 0.5, S * 0.72, S * 0.28)
    icons["ic_w_storm"] = paste(c, dark, S * 0.5, S * 0.40, S * 0.92)
    c = flakes(blank())
    icons["ic_w_snow"] = paste(c, clouds["cloud_a"], S * 0.5, S * 0.42, S * 0.92)
    c = paste(blank(), clouds["cloud_a"], S * 0.5, S * 0.38, S * 0.88)
    fogimg = Image.new("RGBA", (S, S))
    d = ImageDraw.Draw(fogimg)
    for i, (x0, x1) in enumerate(((0.2, 0.78), (0.28, 0.86), (0.18, 0.7))):
        y = S * (0.66 + i * 0.1)
        d.line([(S * x0, y), (S * x1, y)], fill=(235, 240, 245, 230 - i * 40), width=int(S * 0.05))
    icons["ic_w_fog"] = over(c, np.asarray(fogimg.filter(ImageFilter.GaussianBlur(1.2)), dtype=float) / 255)
    for n, arr in icons.items():
        save(arr, n, "xxhdpi")

    # launcher foreground: 108dp canvas, art inside the 66dp safe zone
    L = int(108 * s)
    fg = sun(np.zeros((L, L, 4)), L * 0.42, L * 0.42, L * 0.26)
    fg = paste(fg, clouds["cloud_a"], L * 0.55, L * 0.60, L * 0.52)
    save(fg, "ic_launcher_fg", "xxhdpi")
    return icons


if __name__ == "__main__":
    clouds = make_clouds()
    make_fog()
    make_sun()
    make_moon()
    make_star()
    make_rain()
    make_snow()
    make_bolt()
    make_icons(clouds)
    print("art done")
