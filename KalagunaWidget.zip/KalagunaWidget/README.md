# කාලගුණය – සජීවී (Animated) Weather Widget 🌤️

Android home screen එකට දාගන්න පුළුවන්, animation සහිත කාලගුණ widget එකක්.

## තියෙන දේවල්
- 🌞 කැරකෙන හිරු කිරණ, ☁️ පාවෙන වලාකුළු, 🌧️ වැටෙන වැසි බිංදු, ⚡ අකුණු, ❄️ හිම, 🌫️ මීදුම, 🌙 දිලිසෙන තරු
- කාලගුණය සහ දවල්/රෑ අනුව background පාට වෙනස් වෙනවා
- උෂ්ණත්වය, ඉහළම/පහළම, දැනෙන උෂ්ණත්වය, ආර්ද්‍රතාව, සුළඟ
- ඉදිරි පැය 12 (පැය 3න් 3ට) forecast එක
- සිංහල විස්තර (පැහැදිලි අහස, වැසි, ගිගුරුම් සහිත වැසි…)
- Widget size 2 ක්: කුඩා (2×2) සහ ලොකු (4×2) – resize කරද්දී auto මාරු වෙනවා
- විනාඩි 30කට වරක් auto update · ⟳ ඔබලා අතින් refresh
- ලංකාවේ නගර 12ක් එක tap එකෙන් තෝරන්න, නැත්නම් ලෝකයේ ඕනම නගරයක් search කරන්න
- Data: [Open-Meteo](https://open-meteo.com) – free, API key ඕන නැහැ

## Install කරන විදිය

### ක්‍රමය 1: Android Studio (Computer එකකින්)
1. [Android Studio](https://developer.android.com/studio) install කරන්න.
2. මේ zip එක extract කරලා **File → Open** කරලා `KalagunaWidget` folder එක තෝරන්න.
3. Gradle sync ඉවර වෙනකම් ඉන්න (පළමු වතාවට විනාඩි කීපයක් යනවා).
4. Phone එකේ **Developer options → USB debugging** on කරලා USB එකෙන් connect කරන්න.
5. ▶ **Run** ඔබන්න. App එක phone එකට install වෙනවා.

### ක්‍රමය 2: GitHub වලින් APK එක හදාගන්න (Android Studio නැතුව)
1. GitHub එකේ අලුත් repository එකක් හදලා මේ files ඔක්කොම upload කරන්න.
2. **Actions** tab එකට ගිහින් "Build APK" workflow එක run වෙනකම් ඉන්න (විනාඩි 5ක් විතර).
3. ඉවර වුණාම **Artifacts** යටතේ තියෙන `kalaguna-widget-apk` download කරලා phone එකේ install කරන්න.
   (Unknown apps install කරන්න permission ඉල්ලුවොත් allow කරන්න.)

## Widget එක දාගන්න
- App එක open කරලා **"➕ Widget එක Home Screen එකට දාන්න"** ඔබන්න, නැත්නම්
- Home screen එකේ හිස් තැනක් ඔබාගෙන ඉන්න → **Widgets** → **කාලගුණය** → ඇදලා දාන්න.

## වෙනස් කරන්න කැමති නම්
| වෙනස් කරන්න ඕන දේ | File එක |
|---|---|
| Background පාට | `app/src/main/res/drawable/bg_*.xml` |
| Widget layout | `app/src/main/res/layout/widget_weather.xml` |
| සිංහල වචන | `app/src/main/java/.../Weather.kt` → `conditionSi()` |
| Update වෙන වාර ගණන | `WeatherWorker.kt` → `schedule()` |
| Animations (හිරු, වැසි…) | `tools/gen_drawables.py` run කරලා අලුතෙන් හදන්න |

Animations ටික `tools/gen_drawables.py` එකෙන් auto හදපු vector frames. පාට හෝ වේගය වෙනස් කරලා
`python3 tools/gen_drawables.py app/src/main/res /tmp/preview` run කරන්න.
