package lk.kalaguna.widget

import android.app.Activity
import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Intent
import android.os.Bundle
import android.util.TypedValue
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.MainScope
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.roundToInt

/** Settings screen: pick a city, refresh, and add the widget to the home screen. */
class MainActivity : Activity() {

    private val scope = MainScope()
    private lateinit var prefs: Prefs
    private var configWidgetId = AppWidgetManager.INVALID_APPWIDGET_ID

    private val sriLankaCities = listOf(
        Place("Chilaw", "North Western", 7.5758, 79.7953),
        Place("Madampe", "North Western", 7.4990, 79.8400),
        Place("Panirendawa", "North Western", 7.4937, 79.9007),
        Place("Colombo", "Western", 6.9271, 79.8612),
        Place("Kandy", "Central", 7.2906, 80.6337),
        Place("Galle", "Southern", 6.0535, 80.2210),
        Place("Nuwara Eliya", "Central", 6.9497, 80.7891),
        Place("Jaffna", "Northern", 9.6615, 80.0255),
        Place("Kurunegala", "North Western", 7.4818, 80.3609),
        Place("Anuradhapura", "North Central", 8.3114, 80.4037),
        Place("Trincomalee", "Eastern", 8.5874, 81.2152),
        Place("Batticaloa", "Eastern", 7.7310, 81.6747),
        Place("Matara", "Southern", 5.9549, 80.5550),
        Place("Ratnapura", "Sabaragamuwa", 6.6828, 80.3992),
        Place("Badulla", "Uva", 6.9934, 81.0550),
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        prefs = Prefs(this)

        // Opened by the launcher while adding the widget: keep the widget even if the user just goes back.
        configWidgetId = intent?.extras?.getInt(
            AppWidgetManager.EXTRA_APPWIDGET_ID, AppWidgetManager.INVALID_APPWIDGET_ID
        ) ?: AppWidgetManager.INVALID_APPWIDGET_ID
        if (configWidgetId != AppWidgetManager.INVALID_APPWIDGET_ID) {
            setResult(RESULT_OK, Intent().putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, configWidgetId))
            WeatherWorker.schedule(this)
            WidgetRenderer.updateAll(this)
        }

        buildQuickCities()

        val input = findViewById<EditText>(R.id.search_input)
        findViewById<Button>(R.id.search_btn).setOnClickListener { search(input) }
        input.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_SEARCH) { search(input); true } else false
        }
        findViewById<Button>(R.id.pin_btn).setOnClickListener { pinWidget() }
        findViewById<Button>(R.id.refresh_btn).setOnClickListener { loadWeather() }

        showCard()
        if (prefs.snapshot == null) loadWeather()
    }

    override fun onDestroy() {
        scope.cancel()
        super.onDestroy()
    }

    private fun dp(v: Int) = TypedValue.applyDimension(
        TypedValue.COMPLEX_UNIT_DIP, v.toFloat(), resources.displayMetrics
    ).toInt()

    private fun buildQuickCities() {
        val row = findViewById<LinearLayout>(R.id.quick_cities)
        row.removeAllViews()
        sriLankaCities.forEach { place ->
            val chip = TextView(this).apply {
                text = place.name
                setTextColor(getColor(R.color.text_main))
                textSize = 14f
                setPadding(dp(16), dp(9), dp(16), dp(9))
                background = getDrawable(R.drawable.chip_bg)
                setOnClickListener { choose(place) }
            }
            row.addView(chip, LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply { marginEnd = dp(8) })
        }
    }

    private fun search(input: EditText) {
        val q = input.text.toString()
        if (q.isBlank()) return
        (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager)
            .hideSoftInputFromWindow(input.windowToken, 0)
        val results = findViewById<LinearLayout>(R.id.results)
        results.removeAllViews()
        results.addView(resultRow("හොයමින්…", null))
        scope.launch {
            val found = try {
                withContext(Dispatchers.IO) { WeatherApi.searchCity(q) }
            } catch (e: Exception) {
                null
            }
            results.removeAllViews()
            when {
                found == null -> results.addView(resultRow("Internet සම්බන්ධතාවය බලන්න", null))
                found.isEmpty() -> results.addView(resultRow("\"$q\" හමු වුණේ නැහැ", null))
                else -> found.forEach { results.addView(resultRow("${it.name}  ·  ${it.region}", it)) }
            }
        }
    }

    private fun resultRow(label: String, place: Place?) = TextView(this).apply {
        text = label
        setTextColor(getColor(if (place != null) R.color.text_main else R.color.text_soft))
        textSize = 15f
        setPadding(dp(4), dp(12), dp(4), dp(12))
        if (place != null) setOnClickListener { choose(place) }
    }

    private fun choose(place: Place) {
        prefs.setPlace(place.name, place.lat, place.lon)
        findViewById<LinearLayout>(R.id.results).removeAllViews()
        WidgetRenderer.updateAll(this) // shows "loading" with the new city name
        Toast.makeText(this, "${place.name} තෝරා ගත්තා", Toast.LENGTH_SHORT).show()
        loadWeather()
        if (configWidgetId != AppWidgetManager.INVALID_APPWIDGET_ID) finish()
    }

    private fun loadWeather() {
        findViewById<TextView>(R.id.card_cond).text = getString(R.string.loading)
        // The worker survives this screen closing; the direct fetch updates this screen quickly.
        WeatherWorker.refreshNow(this)
        scope.launch {
            try {
                val snap = withContext(Dispatchers.IO) { WeatherApi.fetch(prefs.lat, prefs.lon, prefs.city) }
                prefs.snapshot = snap
                WidgetRenderer.updateAll(this@MainActivity)
            } catch (e: Exception) {
                Toast.makeText(this@MainActivity, getString(R.string.no_data), Toast.LENGTH_SHORT).show()
            }
            showCard()
        }
    }

    private fun showCard() {
        val snap = prefs.snapshot
        findViewById<TextView>(R.id.card_city).text = "📍 ${prefs.city}"
        findViewById<TextView>(R.id.card_temp).text = snap?.let { "${it.temp.roundToInt()}°C" } ?: "--°"
        findViewById<TextView>(R.id.card_cond).text = snap?.let { conditionSi(it.code) } ?: getString(R.string.no_data)
        findViewById<ImageView>(R.id.card_icon).setImageResource(
            Scene.fromCode(snap?.code ?: 2).icon(snap?.isDay ?: true)
        )
    }

    private fun pinWidget() {
        val mgr = AppWidgetManager.getInstance(this)
        if (mgr.isRequestPinAppWidgetSupported) {
            mgr.requestPinAppWidget(ComponentName(this, WeatherWidgetProvider::class.java), null, null)
        } else {
            Toast.makeText(
                this,
                "Home screen එකේ හිස් තැනක් ඔබාගෙන ඉන්න → Widgets → කාලගුණය",
                Toast.LENGTH_LONG
            ).show()
        }
    }
}
