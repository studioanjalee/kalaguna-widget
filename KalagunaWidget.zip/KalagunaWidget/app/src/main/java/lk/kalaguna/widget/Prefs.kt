package lk.kalaguna.widget

import android.content.Context

/** Saved city + last downloaded weather. Default city is Colombo. */
class Prefs(context: Context) {
    private val sp = context.applicationContext.getSharedPreferences("kalaguna", Context.MODE_PRIVATE)

    var city: String
        get() = sp.getString("city", "Colombo") ?: "Colombo"
        set(v) = sp.edit().putString("city", v).apply()

    var lat: Double
        get() = sp.getFloat("lat", 6.9271f).toDouble()
        set(v) = sp.edit().putFloat("lat", v.toFloat()).apply()

    var lon: Double
        get() = sp.getFloat("lon", 79.8612f).toDouble()
        set(v) = sp.edit().putFloat("lon", v.toFloat()).apply()

    var snapshot: WeatherSnapshot?
        get() = WeatherSnapshot.fromJson(sp.getString("snapshot", null))
        set(v) = sp.edit().putString("snapshot", v?.toJson()).apply()

    fun setPlace(name: String, lat: Double, lon: Double) {
        sp.edit()
            .putString("city", name)
            .putFloat("lat", lat.toFloat())
            .putFloat("lon", lon.toFloat())
            .remove("snapshot") // old city's weather is no longer valid
            .apply()
    }
}
