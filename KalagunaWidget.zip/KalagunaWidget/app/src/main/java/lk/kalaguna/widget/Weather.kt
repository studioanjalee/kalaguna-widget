package lk.kalaguna.widget

import org.json.JSONArray
import org.json.JSONObject

/** One small forecast slot shown in the bottom row of the widget. */
data class HourSlot(val time: String, val temp: Double, val code: Int, val isDay: Boolean)

/** Everything the widget needs to draw itself. Stored as JSON so it works offline. */
data class WeatherSnapshot(
    val city: String,
    val temp: Double,
    val feelsLike: Double,
    val humidity: Int,
    val windKmh: Double,
    val code: Int,
    val isDay: Boolean,
    val max: Double,
    val min: Double,
    val hours: List<HourSlot>,
    val updatedAt: Long,
) {
    fun toJson(): String = JSONObject().apply {
        put("city", city); put("temp", temp); put("feels", feelsLike)
        put("hum", humidity); put("wind", windKmh); put("code", code)
        put("day", isDay); put("max", max); put("min", min); put("at", updatedAt)
        put("hours", JSONArray().apply {
            hours.forEach {
                put(JSONObject().put("t", it.time).put("temp", it.temp)
                    .put("code", it.code).put("day", it.isDay))
            }
        })
    }.toString()

    companion object {
        fun fromJson(s: String?): WeatherSnapshot? = try {
            if (s == null) null else JSONObject(s).let { o ->
                val arr = o.getJSONArray("hours")
                WeatherSnapshot(
                    city = o.getString("city"),
                    temp = o.getDouble("temp"),
                    feelsLike = o.getDouble("feels"),
                    humidity = o.getInt("hum"),
                    windKmh = o.getDouble("wind"),
                    code = o.getInt("code"),
                    isDay = o.getBoolean("day"),
                    max = o.getDouble("max"),
                    min = o.getDouble("min"),
                    hours = (0 until arr.length()).map { i ->
                        val h = arr.getJSONObject(i)
                        HourSlot(h.getString("t"), h.getDouble("temp"), h.getInt("code"), h.getBoolean("day"))
                    },
                    updatedAt = o.getLong("at"),
                )
            }
        } catch (e: Exception) {
            null
        }
    }
}

/** The animated scene the widget shows, chosen from the WMO weather code. */
enum class Scene(val sceneViewId: Int, val bgDay: Int, val bgNight: Int) {
    CLEAR(R.id.scene_clear_day, R.drawable.bg_clear_day, R.drawable.bg_clear_night),
    PARTLY(R.id.scene_partly_day, R.drawable.bg_clear_day, R.drawable.bg_cloudy_night),
    CLOUDY(R.id.scene_cloudy, R.drawable.bg_cloudy_day, R.drawable.bg_cloudy_night),
    FOG(R.id.scene_fog, R.drawable.bg_fog, R.drawable.bg_cloudy_night),
    RAIN(R.id.scene_rain, R.drawable.bg_rain, R.drawable.bg_cloudy_night),
    SNOW(R.id.scene_snow, R.drawable.bg_snow, R.drawable.bg_cloudy_night),
    STORM(R.id.scene_storm, R.drawable.bg_storm, R.drawable.bg_storm);

    /** Some scenes look different at night (moon instead of sun). */
    fun viewId(isDay: Boolean): Int = when {
        this == CLEAR && !isDay -> R.id.scene_clear_night
        this == PARTLY && !isDay -> R.id.scene_partly_night
        else -> sceneViewId
    }

    fun background(isDay: Boolean) = if (isDay) bgDay else bgNight

    fun icon(isDay: Boolean): Int = when (this) {
        CLEAR -> if (isDay) R.drawable.ic_w_clear_day else R.drawable.ic_w_clear_night
        PARTLY -> if (isDay) R.drawable.ic_w_partly_day else R.drawable.ic_w_partly_night
        CLOUDY -> R.drawable.ic_w_cloudy
        FOG -> R.drawable.ic_w_fog
        RAIN -> R.drawable.ic_w_rain
        SNOW -> R.drawable.ic_w_snow
        STORM -> R.drawable.ic_w_storm
    }

    companion object {
        val ALL_VIEW_IDS = intArrayOf(
            R.id.scene_clear_day, R.id.scene_clear_night, R.id.scene_partly_day,
            R.id.scene_partly_night, R.id.scene_cloudy, R.id.scene_fog,
            R.id.scene_rain, R.id.scene_snow, R.id.scene_storm,
        )

        fun fromCode(code: Int): Scene = when (code) {
            0, 1 -> CLEAR
            2 -> PARTLY
            3 -> CLOUDY
            45, 48 -> FOG
            in 51..67, in 80..82 -> RAIN
            in 71..77, 85, 86 -> SNOW
            in 95..99 -> STORM
            else -> CLOUDY
        }
    }
}

/** Sinhala description for a WMO weather code. */
fun conditionSi(code: Int): String = when (code) {
    0 -> "පැහැදිලි අහස"
    1 -> "බොහෝ දුරට පැහැදිලියි"
    2 -> "අර්ධ වශයෙන් වලාකුළු"
    3 -> "වලාකුළු සහිතයි"
    45, 48 -> "මීදුම"
    51, 53, 55 -> "පොද වැසි"
    56, 57 -> "සීතල පොද වැසි"
    61 -> "සුළු වැසි"
    63 -> "වැසි"
    65 -> "තද වැසි"
    66, 67 -> "සීතල වැසි"
    71, 73, 75, 77 -> "හිම පතනය"
    80 -> "වරින් වර වැසි"
    81 -> "වැසි ඇති වේ"
    82 -> "තද වැසි ඇති වේ"
    85, 86 -> "හිම වැසි"
    95 -> "ගිගුරුම් සහිත වැසි"
    96, 99 -> "ගිගුරුම් සහ අයිස් කැට"
    else -> "කාලගුණය"
}
