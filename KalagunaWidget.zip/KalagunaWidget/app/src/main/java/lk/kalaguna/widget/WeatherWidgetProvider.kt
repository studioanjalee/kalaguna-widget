package lk.kalaguna.widget

import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context
import android.content.Intent
import android.os.Bundle

class WeatherWidgetProvider : AppWidgetProvider() {

    override fun onUpdate(context: Context, mgr: AppWidgetManager, ids: IntArray) {
        ids.forEach { mgr.updateAppWidget(it, WidgetRenderer.viewsFor(context, mgr, it)) }
        // Keep the 30-minute schedule alive, and fetch now only if the data is old.
        // (Fetching on every onUpdate can cause an update loop with WorkManager.)
        WeatherWorker.schedule(context)
        val snap = Prefs(context).snapshot
        if (snap == null || System.currentTimeMillis() - snap.updatedAt > 15 * 60 * 1000) {
            WeatherWorker.refreshNow(context)
        }
    }

    override fun onAppWidgetOptionsChanged(context: Context, mgr: AppWidgetManager, id: Int, newOptions: Bundle) {
        mgr.updateAppWidget(id, WidgetRenderer.viewsFor(context, mgr, id))
    }

    override fun onEnabled(context: Context) {
        WeatherWorker.schedule(context)
        WeatherWorker.refreshNow(context)
    }

    override fun onDisabled(context: Context) {
        WeatherWorker.cancel(context)
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        if (intent.action == ACTION_REFRESH) {
            WeatherWorker.refreshNow(context)
        }
    }

    companion object {
        const val ACTION_REFRESH = "lk.kalaguna.widget.ACTION_REFRESH"
    }
}
