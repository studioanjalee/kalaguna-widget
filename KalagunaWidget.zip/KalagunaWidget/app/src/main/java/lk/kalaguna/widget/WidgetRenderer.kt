package lk.kalaguna.widget

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.Build
import android.util.SizeF
import android.view.View
import android.widget.RemoteViews
import kotlin.math.roundToInt

/** Builds the widget's RemoteViews from the saved weather. */
object WidgetRenderer {

    private val HOUR_IDS = arrayOf(
        intArrayOf(R.id.h1_time, R.id.h1_icon, R.id.h1_temp),
        intArrayOf(R.id.h2_time, R.id.h2_icon, R.id.h2_temp),
        intArrayOf(R.id.h3_time, R.id.h3_icon, R.id.h3_temp),
        intArrayOf(R.id.h4_time, R.id.h4_icon, R.id.h4_temp),
    )

    fun updateAll(context: Context) {
        val mgr = AppWidgetManager.getInstance(context)
        val ids = mgr.getAppWidgetIds(ComponentName(context, WeatherWidgetProvider::class.java))
        ids.forEach { mgr.updateAppWidget(it, viewsFor(context, mgr, it)) }
    }

    fun viewsFor(context: Context, mgr: AppWidgetManager, widgetId: Int): RemoteViews {
        val snap = Prefs(context).snapshot
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            // Android 12+: the launcher picks the layout that fits as the widget is resized.
            RemoteViews(
                mapOf(
                    SizeF(100f, 100f) to build(context, snap, small = true),
                    SizeF(180f, 110f) to build(context, snap, small = false),
                )
            )
        } else {
            val minW = mgr.getAppWidgetOptions(widgetId)
                .getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_WIDTH, 250)
            build(context, snap, small = minW < 180)
        }
    }

    private fun build(context: Context, snap: WeatherSnapshot?, small: Boolean): RemoteViews {
        val layout = if (small) R.layout.widget_weather_small else R.layout.widget_weather
        val rv = RemoteViews(context.packageName, layout)
        val city = snap?.city ?: Prefs(context).city

        val scene = Scene.fromCode(snap?.code ?: 0)
        val isDay = snap?.isDay ?: true
        val shown = scene.viewId(isDay)
        Scene.ALL_VIEW_IDS.forEach { id ->
            rv.setViewVisibility(id, if (id == shown) View.VISIBLE else View.GONE)
        }
        rv.setImageViewResource(R.id.bg, scene.background(isDay))
        rv.setTextViewText(R.id.city, city)
        rv.setTextViewText(R.id.temp, snap?.let { "${it.temp.roundToInt()}°" } ?: "--°")

        if (!small) {
            if (snap == null) {
                rv.setTextViewText(R.id.condition, context.getString(R.string.loading))
                rv.setTextViewText(R.id.hilo, "")
                rv.setTextViewText(R.id.details, context.getString(R.string.no_data))
                rv.setViewVisibility(R.id.hourly, View.INVISIBLE)
            } else {
                rv.setTextViewText(R.id.condition, conditionSi(snap.code))
                rv.setTextViewText(R.id.hilo, "↑${snap.max.roundToInt()}°  ↓${snap.min.roundToInt()}°")
                rv.setTextViewText(
                    R.id.details,
                    "දැනෙන්නේ ${snap.feelsLike.roundToInt()}° · 💧${snap.humidity}% · 💨${snap.windKmh.roundToInt()} km/h"
                )
                rv.setViewVisibility(R.id.hourly, View.VISIBLE)
                HOUR_IDS.forEachIndexed { i, ids ->
                    val h = snap.hours.getOrNull(i)
                    rv.setTextViewText(ids[0], h?.time ?: "")
                    rv.setTextViewText(ids[2], h?.let { "${it.temp.roundToInt()}°" } ?: "")
                    rv.setImageViewResource(ids[1], Scene.fromCode(h?.code ?: 0).icon(h?.isDay ?: true))
                    rv.setViewVisibility(ids[1], if (h == null) View.INVISIBLE else View.VISIBLE)
                }
            }
        }

        // Tap anywhere -> open the app (change city). Tap ⟳ -> refresh now.
        val open = PendingIntent.getActivity(
            context, 0, Intent(context, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        rv.setOnClickPendingIntent(R.id.widget_root, open)

        val refresh = PendingIntent.getBroadcast(
            context, 1,
            Intent(context, WeatherWidgetProvider::class.java).setAction(WeatherWidgetProvider.ACTION_REFRESH),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        rv.setOnClickPendingIntent(R.id.refresh, refresh)
        return rv
    }
}
