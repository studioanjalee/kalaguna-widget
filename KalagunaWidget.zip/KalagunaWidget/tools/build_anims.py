"""Writes the animation drawables (XML) used by the widget layers.

Usage: python3 tools/build_anims.py app/src/main/res

How the motion works inside a home-screen widget:
A ProgressBar animates the *level* (0..10000) of its indeterminate drawable at full frame
rate. A <rotate> drawable turns that level into an angle. If the pivot is placed very far
away (tens of thousands of dp), a tiny rotation is practically a straight-line slide, so
clouds drift sideways and rain/snow fall down smoothly - with nothing but cheap bitmap draws.
Each layer contains copies spaced exactly one sweep apart, so the loop is seamless.
"""
import math
import os
import sys

RES = sys.argv[1]
D = os.path.join(RES, "drawable")
os.makedirs(D, exist_ok=True)
NS = 'xmlns:android="http://schemas.android.com/apk/res/android"'
BOX_W, BOX_H = 440, 260          # dp; centred horizontally, aligned to the widget top
CLOUD_ASPECT = {"cloud_a": 230 / 130, "cloud_b": 190 / 110, "cloud_c": 260 / 125, "cloud_d": 150 / 90,
                "cloud_wisp": 300 / 70, "fog_band": 440 / 90}


# Skia snaps sin(angle) to 0 when |sin| < 1/4096, which would freeze tiny rotations.
# So every slide rotates around BASE_DEG and an inner fixed rotation cancels BASE_DEG.
BASE_DEG = 5.0


def slide(frm, to, px, py, inner_rows):
    return f'''        <rotate android:fromDegrees="{f2(BASE_DEG + frm)}" android:toDegrees="{f2(BASE_DEG + to)}"
            android:pivotX="{px}" android:pivotY="{py}">
            <rotate android:fromDegrees="{f2(-BASE_DEG)}" android:toDegrees="{f2(-BASE_DEG)}"
                android:pivotX="{px}" android:pivotY="{py}">
                <layer-list>
{inner_rows}
                </layer-list>
            </rotate>
        </rotate>'''


def write(name, body):
    with open(os.path.join(D, name + ".xml"), "w") as f:
        f.write('<?xml version="1.0" encoding="utf-8"?>\n' + body)


def tinted(name, src, color):
    """Bitmap tinted by multiply (also used for transparency: alpha in the tint colour)."""
    write(name, f'<bitmap {NS}\n    android:src="@drawable/{src}"\n    android:tint="{color}"\n'
                f'    android:tintMode="multiply"\n    android:filter="true" />\n')


def f2(x):
    return f"{x:.6f}".rstrip("0").rstrip(".")


def drift(name, items, speed_dir=1, pivot_pct=15000):
    """Horizontal drifting layer.
    items: list of (drawable, width_dp, top_dp, phase 0..1). Each item crosses the box once per cycle.
    All items in one layer share one sweep S = BOX_W + max width."""
    wmax = max(w for _, w, _, _ in items)
    S = BOX_W + wmax
    pivot_y = pivot_pct / 100 * BOX_H
    rows, radii = [], []
    for src, w, top, phase in items:
        base = next(k for k in sorted(CLOUD_ASPECT, key=len, reverse=True) if src.startswith(k))
        h = w / CLOUD_ASPECT[base]
        x_start = -w + phase * S            # position at level 0 (left side, or right when reversed)
        mid = x_start + S / 2               # position at angle 0 (middle of the sweep)
        if speed_dir < 0:
            mid = BOX_W - (mid + w)         # mirror for right-to-left drift
        for copy in (0, -1):
            x = mid + copy * S * speed_dir
            rows.append(f'            <item android:left="{f2(x)}dp" android:top="{f2(top)}dp" '
                        f'android:width="{f2(w)}dp" android:height="{f2(h)}dp" android:gravity="left|top"\n'
                        f'                android:drawable="@drawable/{src.replace("__", "_")}" />')
        radii.append(pivot_y - (top + h / 2))
    R = sum(radii) / len(radii)
    half = math.degrees(math.asin(S / (2 * R)))
    frm, to = (-half, half) if speed_dir > 0 else (half, -half)
    write(name, f'''<layer-list {NS}>
    <item android:width="{BOX_W}dp" android:height="{BOX_H}dp" android:gravity="top|center_horizontal">
{slide(frm, to, "50%", f"{pivot_pct}%", chr(10).join(rows))}
    </item>
</layer-list>
''')


def fall(name, tile, d=(0, 200), tile_dp=200):
    """Seamless falling layer made of tiles; moves by vector d (dp) per cycle (a tile-lattice vector)."""
    dx, dy = d
    L = math.hypot(dx, dy)
    R = 440000.0
    # pivot so that clockwise rotation moves points along d: radius direction = (dy, -dx)/L
    rx, ry = dy / L, -dx / L
    px = (BOX_W / 2 - R * rx) / BOX_W * 100
    py = (BOX_H / 2 - R * ry) / BOX_H * 100
    deg = math.degrees(math.asin(L / R))
    xs = range(0 if dx >= 0 else 0, BOX_W + abs(dx) + tile_dp, tile_dp)
    ys = range(-dy - (dy % tile_dp) if dy else 0, BOX_H + tile_dp, tile_dp)
    rows = [f'            <item android:left="{x}dp" android:top="{y}dp" android:width="{tile_dp}dp" '
            f'android:height="{tile_dp}dp" android:gravity="left|top" android:drawable="@drawable/{tile}" />'
            for x in xs for y in ys]
    write(name, f'''<layer-list {NS}>
    <item android:width="{BOX_W}dp" android:height="{BOX_H}dp" android:gravity="top|center_horizontal">
{slide(0, deg, f"{px:.3f}%", f"{py:.3f}%", chr(10).join(rows))}
    </item>
</layer-list>
''')


# ---- tinted variants ------------------------------------------------------------
TINTS = {  # name: colour (AARRGGBB, multiply)
    "white": "#FFF4F7FB", "white_t": "#B3FFFFFF",
    "grey": "#FFD3DAE4", "grey_t": "#A6CBD3DE",
    "dark": "#FF8E98AA", "dark_t": "#8C8A95A8",
    "night": "#FF7A879F", "night_t": "#8C707D96",
}
for c in ("cloud_a", "cloud_b", "cloud_c", "cloud_d"):
    for t, col in TINTS.items():
        tinted(f"{c}_{t}", c, col)
tinted("cloud_wisp_soft", "cloud_wisp", "#99FFFFFF")
tinted("fog_band_back", "fog_band", "#B3FFFFFF")
tinted("fog_band_front", "fog_band", "#8CFFFFFF")
tinted("fog_band_night", "fog_band", "#668A96AA")

# ---- cloud layers per tint ---------------------------------------------------------
for t in ("white", "grey", "dark", "night"):
    # far: small, high, slow
    drift(f"layer_{t}_far", [(f"cloud_d__{t}", 110, 4, 0.15), (f"cloud_b__{t}", 130, 26, 0.62)])
    # near: big clouds behind the text
    drift(f"layer_{t}_back", [(f"cloud_a__{t}", 200, 16, 0.55)])
    # front: translucent cloud passing over the letters
    drift(f"layer_{t}_front", [(f"cloud_c__{t}_t", 175, 40, 0.30)], speed_dir=1)
drift("layer_wisp", [("cloud_wisp_soft", 260, 18, 0.35)])
drift("layer_fog_back", [("fog_band_back", 440, 40, 0.2), ("fog_band_back", 440, 95, 0.7)])
drift("layer_fog_front", [("fog_band_front", 440, 70, 0.5)], speed_dir=-1)
drift("layer_fog_night", [("fog_band_night", 440, 55, 0.4)], speed_dir=-1)

# ---- rain & snow ---------------------------------------------------------------------
fall("layer_rain_back", "rain_back", (0, 200))
fall("layer_rain_front", "rain_front", (0, 200))
fall("layer_snow_back", "snow_back", (-200, 400))
fall("layer_snow_front", "snow_front", (-200, 400))

# ---- sun: glow + two ray layers turning opposite ways + core ---------------------------
write("layer_sun", f'''<layer-list {NS}>
    <item android:width="150dp" android:height="150dp" android:gravity="center" android:drawable="@drawable/sun_glow" />
    <item android:width="150dp" android:height="150dp" android:gravity="center">
        <rotate android:fromDegrees="0" android:toDegrees="360" android:pivotX="50%" android:pivotY="50%"
            android:drawable="@drawable/sun_rays" />
    </item>
    <item android:width="150dp" android:height="150dp" android:gravity="center">
        <rotate android:fromDegrees="360" android:toDegrees="0" android:pivotX="50%" android:pivotY="50%"
            android:drawable="@drawable/sun_rays2" />
    </item>
    <item android:width="56dp" android:height="56dp" android:gravity="center" android:drawable="@drawable/sun_core" />
</layer-list>
''')

write("img_moon", f'''<layer-list {NS}>
    <item android:width="130dp" android:height="130dp" android:gravity="center" android:drawable="@drawable/moon_glow" />
    <item android:width="54dp" android:height="54dp" android:gravity="center" android:drawable="@drawable/moon" />
</layer-list>
''')

# ---- twinkling stars (frame animation) ------------------------------------------------
STARS = [(24, 14, 9, 0.0), (118, 30, 7, 0.4), (196, 10, 10, 0.75), (262, 44, 6, 0.2), (330, 18, 8, 0.55),
         (402, 36, 7, 0.9), (60, 64, 6, 0.65), (150, 84, 5, 0.1), (300, 92, 6, 0.35), (380, 76, 5, 0.8),
         (230, 70, 4, 0.5), (90, 112, 4, 0.3), (350, 128, 4, 0.05), (10, 96, 5, 0.85)]
N = 12
for lv in range(1, 6):
    a = int(round(255 * (0.25 + 0.75 * (lv - 1) / 4)))
    tinted(f"star_{lv}", "star", f"#{a:02X}FFFFFF")
frames = []
for i in range(N):
    rows = []
    for (x, y, s, ph) in STARS:
        tw = 0.5 + 0.5 * math.cos(2 * math.pi * (i / N + ph))
        lv = 1 + int(round(tw * 4))
        size = s * (0.75 + 0.35 * tw)
        rows.append(f'                <item android:left="{f2(x - size / 2)}dp" android:top="{f2(y - size / 2)}dp" '
                    f'android:width="{f2(size)}dp" android:height="{f2(size)}dp" android:gravity="left|top" '
                    f'android:drawable="@drawable/star_{lv}" />')
    frames.append(f'''    <item android:duration="160">
        <layer-list>
            <item android:width="{BOX_W}dp" android:height="{BOX_H}dp" android:gravity="top|center_horizontal">
                <layer-list>
{chr(10).join(rows)}
                </layer-list>
            </item>
        </layer-list>
    </item>''')
write("anim_stars", f'<animation-list {NS} android:oneshot="false">\n' + "\n".join(frames) + "\n</animation-list>\n")

# ---- lightning: flashes + bolt (frame animation) --------------------------------------
write("flash_bright", f'<shape {NS} android:shape="rectangle"><solid android:color="#70FFFFFF" /></shape>\n')
write("flash_soft", f'<shape {NS} android:shape="rectangle"><solid android:color="#35E6E9FF" /></shape>\n')
write("flash_none", f'<shape {NS} android:shape="rectangle"><solid android:color="#00000000" /></shape>\n')


def bolt_frame(flash, ms, left):
    return f'''    <item android:duration="{ms}">
        <layer-list>
            <item android:drawable="@drawable/{flash}" />
            <item android:width="{BOX_W}dp" android:height="{BOX_H}dp" android:gravity="top|center_horizontal">
                <layer-list>
                    <item android:left="{left}dp" android:top="6dp" android:width="70dp" android:height="124dp"
                        android:gravity="left|top" android:drawable="@drawable/bolt" />
                </layer-list>
            </item>
        </layer-list>
    </item>'''


def plain(flash, ms):
    return f'    <item android:duration="{ms}" android:drawable="@drawable/{flash}" />'


seq = [plain("flash_none", 2600), bolt_frame("flash_bright", 70, 250), plain("flash_none", 70),
       bolt_frame("flash_bright", 60, 250), bolt_frame("flash_soft", 150, 250), plain("flash_none", 3900),
       plain("flash_soft", 90), plain("flash_none", 60), plain("flash_soft", 70), plain("flash_none", 2400),
       bolt_frame("flash_bright", 80, 120), plain("flash_none", 90), bolt_frame("flash_soft", 120, 120),
       plain("flash_none", 3000)]
write("anim_lightning", f'<animation-list {NS} android:oneshot="false">\n' + "\n".join(seq) + "\n</animation-list>\n")
print("anims done")
