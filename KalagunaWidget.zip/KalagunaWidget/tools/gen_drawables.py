"""Generates animated weather drawables (vector frames + animation-lists) for the widget.
Each shape is described once and emitted both as Android <vector> XML and as SVG (for preview)."""
import math, os, sys

OUT = sys.argv[1]            # app/src/main/res
PREVIEW = sys.argv[2]        # folder for svg previews
DRAW = os.path.join(OUT, "drawable")
os.makedirs(DRAW, exist_ok=True)
os.makedirs(PREVIEW, exist_ok=True)

def circle_d(cx, cy, r):
    return (f"M{cx - r:.2f},{cy:.2f} a{r:.2f},{r:.2f} 0 1,0 {2*r:.2f},0 "
            f"a{r:.2f},{r:.2f} 0 1,0 {-2*r:.2f},0 Z")

def rrect_d(x, y, w, h, r):
    r = min(r, w / 2, h / 2)
    return (f"M{x + r:.2f},{y:.2f} h{w - 2*r:.2f} a{r:.2f},{r:.2f} 0 0,1 {r:.2f},{r:.2f} "
            f"v{h - 2*r:.2f} a{r:.2f},{r:.2f} 0 0,1 {-r:.2f},{r:.2f} h{-(w - 2*r):.2f} "
            f"a{r:.2f},{r:.2f} 0 0,1 {-r:.2f},{-r:.2f} v{-(h - 2*r):.2f} "
            f"a{r:.2f},{r:.2f} 0 0,1 {r:.2f},{-r:.2f} Z")

# element: ("path", d, "#RRGGBB", alpha) or ("group", rotate, px, py, tx, ty, [elements])
def P(d, color, alpha=1.0):
    return ("path", d, color, max(0.0, min(1.0, alpha)))

def G(children, rotate=0, px=50, py=50, tx=0, ty=0, scale=1.0):
    return ("group", rotate, px, py, tx, ty, scale, children)

def to_vector(elems, indent="    "):
    out = []
    for e in elems:
        if e[0] == "path":
            _, d, c, a = e
            if a <= 0.001:
                continue
            out.append(f'{indent}<path android:fillColor="{c}" android:fillAlpha="{a:.2f}" '
                       f'android:pathData="{d}"/>')
        else:
            _, rot, px, py, tx, ty, sc, ch = e
            out.append(f'{indent}<group android:rotation="{rot:.2f}" android:pivotX="{px}" '
                       f'android:pivotY="{py}" android:translateX="{tx:.2f}" android:translateY="{ty:.2f}" '
                       f'android:scaleX="{sc}" android:scaleY="{sc}">')
            out.append(to_vector(ch, indent + "    "))
            out.append(f"{indent}</group>")
    return "\n".join(x for x in out if x)

def to_svg(elems):
    out = []
    for e in elems:
        if e[0] == "path":
            _, d, c, a = e
            out.append(f'<path fill="{c}" fill-opacity="{a:.2f}" d="{d}"/>')
        else:
            _, rot, px, py, tx, ty, sc, ch = e
            # android order: translate, then rotate/scale about pivot
            out.append(f'<g transform="translate({tx},{ty}) translate({px},{py}) rotate({rot}) '
                       f'scale({sc}) translate({-px},{-py})">{to_svg(ch)}</g>')
    return "".join(out)

def write_vector(name, elems, size=100):
    xml = (f'<?xml version="1.0" encoding="utf-8"?>\n'
           f'<vector xmlns:android="http://schemas.android.com/apk/res/android"\n'
           f'    android:width="{size}dp" android:height="{size}dp"\n'
           f'    android:viewportWidth="100" android:viewportHeight="100">\n'
           f'{to_vector(elems)}\n</vector>\n')
    with open(os.path.join(DRAW, name + ".xml"), "w") as f:
        f.write(xml)
    with open(os.path.join(PREVIEW, name + ".svg"), "w") as f:
        f.write(f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100" width="200" height="200">'
                f'{to_svg(elems)}</svg>')

def write_anim(name, frames, ms):
    items = []
    for i, el in enumerate(frames):
        fname = f"{name}_f{i:02d}"
        write_vector(fname, el)
        items.append(f'    <item android:drawable="@drawable/{fname}" android:duration="{ms}"/>')
    xml = ('<?xml version="1.0" encoding="utf-8"?>\n'
           '<animation-list xmlns:android="http://schemas.android.com/apk/res/android"\n'
           '    android:oneshot="false">\n' + "\n".join(items) + "\n</animation-list>\n")
    with open(os.path.join(DRAW, name + ".xml"), "w") as f:
        f.write(xml)

# ---------------- shapes ----------------
SUN = "#FFC107"; SUN_LIGHT = "#FFE082"; RAY = "#FFCA28"
CLOUD = "#FFFFFF"; CLOUD_SHADE = "#E3EEF6"; CLOUD_BACK = "#C9D8E4"
DARK_CLOUD = "#8796A8"; DARK_SHADE = "#6E7D90"; DARK_BACK = "#56647A"
DROP = "#7FD3FF"; SNOW = "#FFFFFF"; BOLT = "#FFE34D"; MOON = "#FFF1C1"

def sun(glow_extra=0.0, rot=0.0):
    rays = []
    for k in range(8):
        rays.append(G([P(rrect_d(47, 6, 6, 13, 3), RAY)], rotate=k * 45 + rot))
    return [
        P(circle_d(50, 50, 33 + glow_extra), SUN, 0.18),
        P(circle_d(50, 50, 27 + glow_extra * 0.6), SUN, 0.25),
        *rays,
        P(circle_d(50, 50, 21), SUN),
        P(circle_d(46, 46, 14), SUN_LIGHT, 0.9),
    ]

def cloud(x, y, s=1.0, main=CLOUD, shade=CLOUD_SHADE):
    """Puffy cloud; (x, y) = left-bottom of base. Width ~ 60*s."""
    def c(cx, cy, r, col):
        return P(circle_d(x + cx * s, y + cy * s, r * s), col)
    return [
        c(16, -14, 12, shade), c(30, -22, 16, shade), c(46, -14, 12, shade),
        P(rrect_d(x + 2 * s, y - 18 * s, 56 * s, 18 * s, 9 * s), shade),
        c(16, -16, 11, main), c(30, -24, 15, main), c(45, -16, 11, main),
        P(rrect_d(x + 3 * s, y - 20 * s, 54 * s, 17 * s, 8.5 * s), main),
    ]

def crescent(cx, cy, r, color):
    # crescent = outer circle minus inner circle offset up-right
    ox, oy, ir = cx + r * 0.42, cy - r * 0.28, r * 0.86
    d = math.hypot(ox - cx, oy - cy)
    a = (r * r - ir * ir + d * d) / (2 * d)
    h = math.sqrt(max(r * r - a * a, 0))
    mx, my = cx + a * (ox - cx) / d, cy + a * (oy - cy) / d
    p1 = (mx + h * (oy - cy) / d, my - h * (ox - cx) / d)
    p2 = (mx - h * (oy - cy) / d, my + h * (ox - cx) / d)
    path = (f"M{p1[0]:.2f},{p1[1]:.2f} A{r:.2f},{r:.2f} 0 1,0 {p2[0]:.2f},{p2[1]:.2f} "
            f"A{ir:.2f},{ir:.2f} 0 0,1 {p1[0]:.2f},{p1[1]:.2f} Z")
    return [P(circle_d(cx, cy, r * 1.25), color, 0.12), P(path, color)]

def star(cx, cy, s, alpha):
    d = (f"M{cx:.2f},{cy - s:.2f} Q{cx:.2f},{cy:.2f} {cx + s:.2f},{cy:.2f} "
         f"Q{cx:.2f},{cy:.2f} {cx:.2f},{cy + s:.2f} Q{cx:.2f},{cy:.2f} {cx - s:.2f},{cy:.2f} "
         f"Q{cx:.2f},{cy:.2f} {cx:.2f},{cy - s:.2f} Z")
    return P(d, "#FFFFFF", alpha)

def drop(x, y, alpha, color=DROP):
    return G([P(rrect_d(x - 1.6, y - 5, 3.2, 10, 1.6), color, alpha)], rotate=12, px=x, py=y)

def bolt(alpha):
    d = "M53,60 L42,78 L51,78 L46,96 L63,72 L54,72 L59,60 Z"
    return [P(d, BOLT, alpha * 0.35), G([P(d, BOLT, alpha)], scale=0.82, px=52, py=78)]

# ---------------- animations ----------------
# 1. Sun: rotating rays + breathing glow (rays repeat every 45 degrees)
N = 18
write_anim("anim_sun", [sun(2.5 * math.sin(2 * math.pi * i / N), i * 45 / N) for i in range(N)], 70)

# 2. Stars twinkling (moon drawn as static image underneath)
STARS = [(14, 18, 4.5, 0.0), (82, 22, 3.5, 0.33), (78, 74, 4.0, 0.66), (20, 80, 3.0, 0.5), (90, 50, 2.6, 0.15)]
N = 12
frames = []
for i in range(N):
    els = []
    for (x, y, s, ph) in STARS:
        t = (i / N + ph) % 1.0
        a = 0.25 + 0.75 * (0.5 + 0.5 * math.cos(2 * math.pi * t))
        els.append(star(x, y, s * (0.7 + 0.3 * a), a))
    frames.append(els)
write_anim("anim_stars", frames, 110)

# 3. Single cloud drifting (for partly cloudy - sits bottom right)
N = 16
write_anim("anim_cloud_drift",
           [cloud(34 + 4 * math.sin(2 * math.pi * i / N), 86, 1.0) for i in range(N)], 120)

# 4. Overcast: back + front cloud drifting opposite
frames = []
for i in range(N):
    t = 2 * math.pi * i / N
    frames.append(cloud(30 - 4 * math.sin(t), 52, 0.9, CLOUD_BACK, "#B4C5D3")
                  + cloud(16 + 5 * math.sin(t), 82, 1.08))
write_anim("anim_clouds", frames, 120)

# 5. Rain drops (static cloud drawn on top as image)
def rain_frames(n, cols, color=DROP, speed=1.0):
    fr = []
    for i in range(n):
        els = []
        for (x, ph) in cols:
            for k in range(2):
                t = ((i / n) * speed + ph + k * 0.5) % 1.0
                y = 58 + t * 34
                a = 1.0 - t * 0.85 if t > 0.08 else t / 0.08
                els.append(drop(x - t * 4, y, a, color))
        fr.append(els)
    return fr
RAIN_COLS = [(30, 0.0), (42, 0.35), (54, 0.7), (66, 0.15), (78, 0.55)]
write_anim("anim_rain", rain_frames(10, RAIN_COLS), 70)

# 6. Storm: heavier rain + lightning flashes
storm = rain_frames(14, RAIN_COLS + [(36, 0.85), (60, 0.45)], "#A8C8FF")
flash = {9: 1.0, 10: 0.4, 11: 1.0, 12: 0.6}
for i, a in flash.items():
    storm[i] = storm[i] + bolt(a)
write_anim("anim_storm", storm, 80)

# 7. Snow: flakes falling with sway
N = 16
frames = []
FLAKES = [(30, 0.0, 3.0), (44, 0.4, 2.4), (58, 0.75, 3.2), (72, 0.2, 2.6), (37, 0.6, 2.2), (65, 0.9, 2.8)]
for i in range(N):
    els = []
    for (x, ph, r) in FLAKES:
        t = (i / N + ph) % 1.0
        y = 58 + t * 34
        sx = x + 3 * math.sin(2 * math.pi * (t * 1.5 + ph))
        a = 1.0 - t * 0.7 if t > 0.1 else t / 0.1
        els.append(P(circle_d(sx, y, r), SNOW, a))
    frames.append(els)
write_anim("anim_snow", frames, 110)

# 8. Fog bands sliding
N = 16
frames = []
for i in range(N):
    t = 2 * math.pi * i / N
    els = []
    for k, (y, w, ph) in enumerate([(62, 56, 0), (73, 46, 2.1), (84, 52, 4.2)]):
        x = 50 - w / 2 + 7 * math.sin(t + ph)
        els.append(P(rrect_d(x, y, w, 5.5, 2.75), "#FFFFFF", 0.75 - k * 0.12))
    frames.append(els)
write_anim("anim_fog", frames, 130)

# ---------------- static pieces ----------------
write_vector("img_moon", crescent(52, 50, 30, MOON))
write_vector("img_cloud_top", cloud(18, 58, 1.08))
write_vector("img_cloud_dark", cloud(30, 40, 0.85, DARK_BACK, "#4A576B") + cloud(16, 60, 1.08, DARK_CLOUD, DARK_SHADE))
write_vector("img_cloud_fog", cloud(20, 54, 1.0, "#EEF3F7", "#D5DFE7"))

# ---------------- small static icons (hourly forecast) ----------------
write_vector("ic_w_clear_day", sun(), 24)
write_vector("ic_w_clear_night", crescent(52, 50, 30, MOON), 24)
write_vector("ic_w_partly_day", [G(sun(), scale=0.62, px=32, py=34)] + cloud(30, 88, 1.05), 24)
write_vector("ic_w_partly_night", [G(crescent(50, 50, 30, MOON), scale=0.6, px=30, py=30)] + cloud(30, 88, 1.05), 24)
write_vector("ic_w_cloudy", cloud(30, 52, 0.9, CLOUD_BACK, "#B4C5D3") + cloud(16, 82, 1.08), 24)
write_vector("ic_w_rain", rain_frames(10, RAIN_COLS)[3] + cloud(18, 58, 1.08), 24)
write_vector("ic_w_storm", rain_frames(14, RAIN_COLS, "#A8C8FF")[3] + bolt(1.0) + cloud(16, 60, 1.08, DARK_CLOUD, DARK_SHADE), 24)
write_vector("ic_w_snow", frames and [P(circle_d(x, 74, r), SNOW) for (x, _, r) in FLAKES[:4]] + cloud(18, 58, 1.08), 24)
write_vector("ic_w_fog", cloud(20, 54, 1.0, "#EEF3F7", "#D5DFE7") + frames[0], 24)

# launcher icon foreground (108dp adaptive canvas, art in the middle 66%)
fg = [G([G(sun(), scale=0.6, px=32, py=34)] + cloud(28, 86, 1.05), scale=0.8, px=50, py=50)]
write_vector("ic_launcher_foreground", fg, 108)
print("done")

# small sun / moon for partly-cloudy scenes (top-left corner, cloud drifts in front)
N = 18
write_anim("anim_sun_small", [[G(sun(2.5 * math.sin(2 * math.pi * i / N), i * 45 / N), scale=0.62, px=30, py=32)]
                              for i in range(N)], 70)
write_vector("img_moon_small", [G(crescent(50, 50, 30, MOON), scale=0.62, px=30, py=30)])
print("extras done")
