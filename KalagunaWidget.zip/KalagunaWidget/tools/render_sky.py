"""Realistic sky art: volumetric (self-shadowed) clouds with ragged bottoms, tileable overcast
cloud decks, motion-blurred rain streaks and a branching lightning bolt.

Run AFTER render_art.py (it replaces the cloud, rain and bolt images):
    python3 tools/render_art.py app/src/main/res
    python3 tools/render_sky.py app/src/main/res
"""
import math
import os
import sys

import numpy as np
from PIL import Image, ImageDraw
from scipy.ndimage import gaussian_filter, map_coordinates

RES = sys.argv[1]


def save(arr, name, bucket):
    d = os.path.join(RES, f"drawable-{bucket}")
    os.makedirs(d, exist_ok=True)
    for b in ("xhdpi", "xxhdpi"):  # make sure only one density holds this name
        p = os.path.join(RES, f"drawable-{b}", name + ".png")
        if b != bucket and os.path.exists(p):
            os.remove(p)
    Image.fromarray((np.clip(arr, 0, 1) * 255 + 0.5).astype(np.uint8), "RGBA").save(
        os.path.join(d, name + ".png"), optimize=True)


def hexc(h):
    h = h.lstrip("#")
    return np.array([int(h[i:i + 2], 16) / 255 for i in (0, 2, 4)])


def noise(h, w, scale, rng, wrap_x=False):
    """Smooth noise ~N(0,1) with feature size `scale` px (periodic in x if wrap_x)."""
    n = rng.standard_normal((h, w))
    mode = ("nearest", "wrap") if wrap_x else "nearest"
    g = gaussian_filter(n, scale, mode=mode)
    return g / (g.std() + 1e-9)


def fbm(h, w, base, rng, octaves=5, wrap_x=False):
    out, amp, tot, s = np.zeros((h, w)), 1.0, 0.0, base
    for _ in range(octaves):
        out += noise(h, w, max(s, 0.6), rng, wrap_x) * amp
        tot += amp
        amp *= 0.55
        s /= 2.0
    return out / tot


def light_march(density, lx, ly, steps, step_px, wrap_x=False, seed=0):
    """Optical depth towards the light (jittered start + smoothing to avoid banding)."""
    h, w = density.shape
    yy, xx = np.mgrid[0:h, 0:w].astype(np.float32)
    jit = np.random.default_rng(seed).uniform(0, 1, (h, w)).astype(np.float32)
    od = np.zeros_like(density)
    for i in range(steps):
        k = (i + jit) * step_px
        od += map_coordinates(density, [yy + ly * k, xx + lx * k], order=1,
                              mode="grid-wrap" if wrap_x else "constant", cval=0.0)
    od *= step_px
    return gaussian_filter(od, step_px * 1.8, mode=("nearest", "wrap") if wrap_x else "nearest")


def shade(density, sun, amb, lx=-0.6, ly=-0.8, sigma=0.008, steps=16, step_px=None, wrap_x=False,
          alpha_k=5.0, bottom_dark=0.0, ambient_floor=0.62):
    """density in ~0..1.5. Single + multiple scattering approximation with Beer's law."""
    h, w = density.shape
    n = math.hypot(lx, ly)
    lx, ly = lx / n, ly / n
    step_px = step_px or max(2.0, h / 45)
    od = light_march(density, lx, ly, steps, step_px, wrap_x)
    trans = 0.55 * np.exp(-od * sigma) + 0.45 * np.exp(-od * sigma * 0.2)   # multi-scatter keeps cores bright-ish
    powder = 1 - np.exp(-density * 4.0)
    lit = np.clip(trans * (0.75 + 0.25 * powder) * 1.12, 0, 1)
    yy = np.linspace(0, 1, h)[:, None]
    ambient = ambient_floor + (1 - ambient_floor) * (1 - yy) * 0.6           # sky light from above
    shadow_col = amb[None, None, :] * ambient[..., None]
    col = shadow_col * (1 - lit[..., None]) + sun[None, None, :] * lit[..., None]
    if bottom_dark:
        col *= (1 - bottom_dark * (yy ** 1.5)[..., None])
    alpha = 1 - np.exp(-density * alpha_k)
    return np.concatenate([np.clip(col, 0, 1), alpha[..., None]], axis=-1)


# ---------------------------------------------------------------- individual clouds
def cumulus(w, h, seed, puffs=6, flatness=0.0):
    """Cumulus: rounded towers on a slightly uneven (not flat) base, organic warped edges."""
    rng = np.random.default_rng(seed)
    yy, xx = np.mgrid[0:h, 0:w].astype(float)
    shape = np.zeros((h, w))
    base = h * rng.uniform(0.70, 0.76)

    def blob(cx, cy, rx, ry, k=1.0):
        return k * np.exp(-(((xx - cx) / rx) ** 2 + ((yy - cy) / ry) ** 2) * 2.2)

    for i in range(puffs):  # towers sitting on the base
        t = (i + 0.5) / puffs
        mid = 1 - abs(t - 0.5) * 1.9
        r = h * (0.17 + 0.17 * max(mid, 0)) * rng.uniform(0.85, 1.15)
        cx = w * (0.22 + 0.56 * t) + rng.uniform(-0.03, 0.03) * w
        cy = base - r * 0.95 - h * 0.08 * max(mid, 0)
        shape += blob(cx, cy, r * 1.15, r)
        for _ in range(2):  # small cauliflower knobs
            a = rng.uniform(math.pi * 1.1, math.pi * 1.9)
            kr = r * rng.uniform(0.35, 0.55)
            shape += blob(cx + math.cos(a) * r * 0.75, cy + math.sin(a) * r * 0.7, kr, kr, 0.9)
    for i in range(6):  # underside: lumps at different heights -> rounded, uneven bottom
        t = i / 5
        sag = (1 - abs(t - 0.5) * 2) * h * 0.06            # belly hangs a little lower in the middle
        cx = w * (0.24 + 0.52 * t) + rng.uniform(-0.04, 0.04) * w
        cy = base - h * 0.06 + sag + rng.uniform(-0.05, 0.04) * h
        r = h * rng.uniform(0.09, 0.15)
        shape += blob(cx, cy, r * rng.uniform(1.2, 1.8), r, 0.85)
    # organic edges: warp the shape with noise
    wx, wy = fbm(h, w, h * 0.05, rng, 4), fbm(h, w, h * 0.05, rng, 4)
    amp = h * 0.045
    shape = map_coordinates(shape, [yy + wy * amp, xx + wx * amp], order=1, mode="constant", cval=0)
    detail = fbm(h, w, h * 0.018, rng, 4)
    x = shape - 0.55 + 0.10 * detail * np.clip(shape * 2, 0, 1)
    # gentle fade at canvas borders
    edge = np.clip(np.minimum.reduce([xx, w - 1 - xx, yy, h - 1 - yy]) / (h * 0.06), 0, 1)
    dens = np.clip(x / 0.35, 0, None) ** 1.1 * edge
    return gaussian_filter(dens, 0.6)


def make_clouds():
    s = 3.0  # xxhdpi
    specs = [("cloud_a", 240, 140, 11, 6), ("cloud_b", 200, 120, 23, 5), ("cloud_c", 270, 135, 37, 7),
             ("cloud_d", 160, 100, 51, 4)]
    sun, amb = hexc("#FFFDF8"), hexc("#7F8FA8")
    for name, wd, hd, seed, p in specs:
        d = cumulus(int(wd * s), int(hd * s), seed, p)
        save(shade(d, sun, amb), name, "xxhdpi")
    # rain clouds: darker, heavier, more ragged
    rsun, ramb = hexc("#B9C0CB"), hexc("#3E4656")
    for name, wd, hd, seed, p in (("cloud_ra", 300, 150, 61, 8), ("cloud_rb", 240, 125, 73, 6)):
        d = cumulus(int(wd * 2), int(hd * 2), seed, p) * 1.2
        save(shade(d, rsun, ramb, sigma=0.012, bottom_dark=0.2, ambient_floor=0.7), name, "xhdpi")


# ---------------------------------------------------------------- overcast decks (tile horizontally)
def deck(w, h, seed, sun, amb, cover=0.75, base=0.55, ragged=0.22, sigma=0.03, bottom_dark=0.35, top_fade=0.06,
         amb_floor=0.75):
    rng = np.random.default_rng(seed)
    yy = np.linspace(0, 1, h)[:, None] * np.ones((1, w))
    big = fbm(h, w, h * 0.12, rng, 5, wrap_x=True)
    small = fbm(h, w, h * 0.03, rng, 4, wrap_x=True)
    # thick at the top, breaking into ragged hanging lumps near the bottom edge
    edge = base + ragged * big + 0.06 * small
    body = np.clip((edge - yy) / 0.10, 0, 1)
    dens = np.clip(body * (cover + 0.45 * big + 0.25 * small), 0, None)
    dens *= np.clip((1 - yy) / 0.12, 0, 1)  # nothing touches the bottom edge of the image
    dens *= np.clip((yy + 0.02 * big) / top_fade, 0, 1) ** 1.5  # soft, uneven top edge
    dens *= np.clip(yy / 0.04, 0, 1)                              # first rows always fully clear
    dens = gaussian_filter(dens, (1.0, 1.0), mode=("nearest", "wrap"))
    return shade(dens, sun, amb, lx=-0.55, ly=-1.0, steps=16, step_px=h / 40, wrap_x=True, sigma=sigma,
                 alpha_k=4.0, bottom_dark=bottom_dark, ambient_floor=amb_floor)


def make_decks():
    s = 2.0  # xhdpi
    W, H = int(520 * s), int(300 * s)
    save(deck(W, H, 5, hexc("#E9EDF2"), hexc("#7C8797"), cover=0.7, base=0.62, sigma=0.006, bottom_dark=0.15),
         "deck_light", "xhdpi")
    save(deck(W, H, 9, hexc("#A9B2BF"), hexc("#20252E"), cover=0.9, base=0.68, ragged=0.26, sigma=0.014,
              bottom_dark=0.3, amb_floor=0.6),
         "deck_dark", "xhdpi")
    save(deck(W, int(H * 0.8), 15, hexc("#B6BEC9"), hexc("#30363F"), cover=0.6, base=0.62, ragged=0.3, sigma=0.012,
              top_fade=0.35, amb_floor=0.65),
         "deck_scud", "xhdpi")


# ---------------------------------------------------------------- rain
def streak(length_px, width_px, blur):
    L, Wd = int(length_px), int(max(6, width_px * 6))
    img = np.zeros((L + 8, Wd))
    yy = np.linspace(0, 1, L)
    prof = yy ** 1.4                                   # transparent tail, denser head
    img[4:4 + L, Wd // 2] = prof
    img = gaussian_filter(img, (blur * 2.5, max(0.5, width_px * 0.45)))
    img /= img.max() + 1e-9
    col = np.ones(img.shape + (3,)) * hexc("#DCE6F2")
    return np.concatenate([col, img[..., None]], -1)


def make_rain():
    s = 2.0
    save(streak(26 * s, 0.8 * s, 1.0) * [1, 1, 1, 0.55], "streak_far", "xhdpi")
    save(streak(48 * s, 1.1 * s, 1.6) * [1, 1, 1, 0.7], "streak_mid", "xhdpi")
    save(streak(90 * s, 1.8 * s, 3.0) * [1, 1, 1, 0.75], "streak_near", "xhdpi")

    # widget tiles (200x200dp, seamless) built from the streaks
    def tile(name, specs, seed):
        rng = np.random.default_rng(seed)
        T = int(200 * s)
        A, C = np.zeros((T, T)), np.ones((T, T, 3)) * hexc("#DCE6F2")
        for (src_len, src_w, blur, n, amax) in specs:
            st = streak(src_len * s, src_w * s, blur)[..., 3]
            ph, pw = st.shape
            for _ in range(n):
                x, y, a = rng.uniform(0, T), rng.uniform(0, T), rng.uniform(0.4, 1.0) * amax
                for oy in (-T, 0, T):
                    for ox in (-T, 0, T):
                        x0, y0 = int(x + ox), int(y + oy)
                        xa, ya, xb, yb = max(0, x0), max(0, y0), min(T, x0 + pw), min(T, y0 + ph)
                        if xa < xb and ya < yb:
                            piece = st[ya - y0:yb - y0, xa - x0:xb - x0] * a
                            A[ya:yb, xa:xb] = piece + A[ya:yb, xa:xb] * (1 - piece)
        save(np.concatenate([C, A[..., None]], -1), name, "xhdpi")

    tile("rain_back", [(22, 0.8, 1.0, 34, 0.5)], 1)
    tile("rain_front", [(46, 1.2, 1.8, 12, 0.7), (80, 1.8, 3.0, 3, 0.6)], 2)


# ---------------------------------------------------------------- lightning bolt (widget)
def make_bolt():
    s = 3.0
    W, H = int(90 * s), int(170 * s)
    rng = np.random.default_rng(21)

    def path(p0, angle, length, depth, width, out):
        pts, (x, y) = [p0], p0
        segs = int(length / (6 * s)) + 2
        for i in range(segs):
            angle += rng.normal(0, 0.45)
            angle = 0.65 * angle + 0.35 * (math.pi / 2)        # keep heading downward
            step = length / segs * rng.uniform(0.6, 1.4)
            x, y = x + math.cos(angle) * step, y + math.sin(angle) * step
            pts.append((x, y))
            if depth < 2 and rng.random() < 0.18:
                path((x, y), angle + rng.choice([-1, 1]) * rng.uniform(0.5, 1.0), length * rng.uniform(0.25, 0.45),
                     depth + 1, width * 0.5, out)
        out.append((pts, width))

    segs = []
    path((W * 0.5, 0), math.pi / 2, H * 0.98, 0, 2.2 * s, segs)
    core = Image.new("L", (W, H), 0)
    d = ImageDraw.Draw(core)
    for pts, wdt in segs:
        d.line(pts, fill=255, width=max(1, int(wdt)), joint="curve")
    c = np.asarray(core, float) / 255
    glow = gaussian_filter(c, 2 * s) * 3 + gaussian_filter(c, 7 * s) * 4 + gaussian_filter(c, 16 * s) * 3
    a = np.clip(c + glow * 0.6, 0, 1)
    col = hexc("#C9C2FF") * (1 - c[..., None]) + c[..., None]
    save(np.concatenate([col, a[..., None]], -1), "bolt", "xxhdpi")


def make_icons():
    """Rebuild the small hourly icons + launcher icon with the new clouds and bolt."""
    sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
    import render_art as ra
    load = lambda n: np.asarray(Image.open(os.path.join(RES, "drawable-xxhdpi", n + ".png")), float) / 255
    ra.make_icons({"cloud_a": load("cloud_a"), "cloud_b": load("cloud_b")})


if __name__ == "__main__":
    make_clouds()
    make_decks()
    make_rain()
    make_bolt()
    make_icons()
    print("sky art done")
